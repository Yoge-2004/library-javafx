package com.example.entities;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.UUID;

public final class BorrowRequest implements Serializable {
    private static final long serialVersionUID = 1L;

    public enum Status {
        PENDING,
        APPROVED,
        REJECTED
    }

    private final String requestId;
    private final String isbn;
    private final String bookTitle;
    private final String userId;
    private final int quantity;
    private final LocalDateTime requestedAt;

    private Status status;
    private String processedBy;
    private LocalDateTime processedAt;
    private String note;

    public BorrowRequest(String isbn, String bookTitle, String userId, int quantity) {
        this.requestId = UUID.randomUUID().toString();
        this.isbn = Objects.requireNonNull(isbn, "isbn");
        this.bookTitle = Objects.requireNonNull(bookTitle, "bookTitle");
        this.userId = Objects.requireNonNull(userId, "userId");
        this.quantity = Math.max(1, quantity);
        this.requestedAt = LocalDateTime.now();
        this.status = Status.PENDING;
    }

    public String getRequestId() {
        return requestId;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public String getUserId() {
        return userId;
    }

    public int getQuantity() {
        return quantity;
    }

    public LocalDateTime getRequestedAt() {
        return requestedAt;
    }

    public Status getStatus() {
        return status;
    }

    public String getProcessedBy() {
        return processedBy;
    }

    public LocalDateTime getProcessedAt() {
        return processedAt;
    }

    public String getNote() {
        return note;
    }

    public boolean isPending() {
        return status == Status.PENDING;
    }

    public void approve(String processedBy) {
        this.status = Status.APPROVED;
        this.processedBy = processedBy;
        this.processedAt = LocalDateTime.now();
        this.note = null;
    }

    public void reject(String processedBy, String note) {
        this.status = Status.REJECTED;
        this.processedBy = processedBy;
        this.processedAt = LocalDateTime.now();
        this.note = note;
    }
}
