package com.example.entities;

import java.io.Serializable;

public final class AppConfiguration implements Serializable {
    private static final long serialVersionUID = 1L;

    private String exportDirectory = "exports";
    private String smtpHost;
    private int smtpPort = 587;
    private String smtpUsername;
    private String smtpPassword;
    private String fromAddress;
    private boolean smtpAuth = true;
    private boolean startTlsEnabled = true;

    public String getExportDirectory() {
        return exportDirectory;
    }

    public void setExportDirectory(String exportDirectory) {
        this.exportDirectory = exportDirectory == null || exportDirectory.trim().isEmpty()
                ? "exports"
                : exportDirectory.trim();
    }

    public String getSmtpHost() {
        return smtpHost;
    }

    public void setSmtpHost(String smtpHost) {
        this.smtpHost = blankToNull(smtpHost);
    }

    public int getSmtpPort() {
        return smtpPort;
    }

    public void setSmtpPort(int smtpPort) {
        this.smtpPort = Math.max(1, smtpPort);
    }

    public String getSmtpUsername() {
        return smtpUsername;
    }

    public void setSmtpUsername(String smtpUsername) {
        this.smtpUsername = blankToNull(smtpUsername);
    }

    public String getSmtpPassword() {
        return smtpPassword;
    }

    public void setSmtpPassword(String smtpPassword) {
        this.smtpPassword = blankToNull(smtpPassword);
    }

    public String getFromAddress() {
        return fromAddress;
    }

    public void setFromAddress(String fromAddress) {
        this.fromAddress = blankToNull(fromAddress);
    }

    public boolean isSmtpAuth() {
        return smtpAuth;
    }

    public void setSmtpAuth(boolean smtpAuth) {
        this.smtpAuth = smtpAuth;
    }

    public boolean isStartTlsEnabled() {
        return startTlsEnabled;
    }

    public void setStartTlsEnabled(boolean startTlsEnabled) {
        this.startTlsEnabled = startTlsEnabled;
    }

    public boolean isEmailConfigured() {
        return smtpHost != null && fromAddress != null && (!smtpAuth || smtpUsername != null);
    }

    private String blankToNull(String value) {
        return value == null || value.trim().isEmpty() ? null : value.trim();
    }
}
