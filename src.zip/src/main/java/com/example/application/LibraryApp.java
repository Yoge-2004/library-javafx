package com.example.application;

import com.example.application.ui.AnalyticsDashboard;
import com.example.application.ui.AppTheme;
import com.example.application.ui.DataManagementWorkspace;
import com.example.application.ui.LibraryConfigurationDialog;
import com.example.application.ui.RegistrationDialog;
import com.example.application.ui.SettingsWorkspace;
import com.example.application.ui.UserAccountDialogs;
import com.example.entities.Book;
import com.example.entities.BorrowRequest;
import com.example.entities.BooksDB.IssueRecord;
import com.example.entities.AppConfiguration;
import com.example.entities.User;
import com.example.entities.UserRole;
import com.example.services.AppConfigurationService;
import com.example.services.BookService;
import com.example.services.BorrowRequestService;
import com.example.services.ReminderService;
import com.example.services.ReportExportService;
import com.example.services.UserService;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * Enhanced JavaFX application for library management with improved UI/UX,
 * error handling, performance optimizations, and comprehensive settings module.
 */
public class LibraryApp extends Application {

    // Application constants
    private static final String APP_TITLE = "Library Management System";
    private static final String APP_VERSION = "1.0";
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("MMM dd, yyyy");

    // UI State
    private String currentUser;
    private UserRole currentUserRole = UserRole.USER;
    private Stage primaryStage;

    // Data collections
    private final ObservableList<Book> booksList = FXCollections.observableArrayList();
    private FilteredList<Book> filteredBooks;
    private final ObservableList<IssueRecord> issueRecordsList = FXCollections.observableArrayList();
    private FilteredList<IssueRecord> filteredIssueRecords;
    private final ObservableList<BorrowRequest> borrowRequestsList = FXCollections.observableArrayList();

    // UI Components
    private TextField searchField;
    private ListView<Book> booksListView;
    private ListView<IssueRecord> issueRecordsListView;
    private ListView<BorrowRequest> borrowRequestsListView;
    private Label statusLabel;
    private Label statisticsLabel;
    private ProgressIndicator loadingIndicator;
    private AnalyticsDashboard analyticsDashboard;
    private Timeline autoRefreshTimeline;

    // UI Style constants
    private static final String BUTTON_STYLE_PRIMARY =
            "-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-weight: bold; " +
                    "-fx-cursor: hand; -fx-padding: 8 16; -fx-background-radius: 4;";
    private static final String BUTTON_STYLE_SUCCESS =
            "-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-weight: bold; " +
                    "-fx-cursor: hand; -fx-padding: 8 16; -fx-background-radius: 4;";
    private static final String BUTTON_STYLE_DANGER =
            "-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-weight: bold; " +
                    "-fx-cursor: hand; -fx-padding: 8 16; -fx-background-radius: 4;";
    private static final String BUTTON_STYLE_WARNING =
            "-fx-background-color: #f39c12; -fx-text-fill: white; -fx-font-weight: bold; " +
                    "-fx-cursor: hand; -fx-padding: 8 16; -fx-background-radius: 4;";

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;

        primaryStage.setTitle(APP_TITLE + " v" + APP_VERSION);
        primaryStage.setMinWidth(800);
        primaryStage.setMinHeight(600);

        showLoginScreen();
        primaryStage.show();

        // Handle application close
        primaryStage.setOnCloseRequest(event -> handleApplicationClose());
    }

    /**
     * Displays the login screen with enhanced UI and validation.
     */
    private void showLoginScreen() {
        if (autoRefreshTimeline != null) {
            autoRefreshTimeline.stop();
        }

        HBox loginPane = createLoginPane();
        Scene loginScene = AppTheme.createScene(loginPane, 1060, 680);

        primaryStage.setScene(loginScene);
        primaryStage.centerOnScreen();
    }

    /**
     * Creates the login pane with improved styling and functionality.
     */
    private HBox createLoginPane() {
        HBox root = new HBox(24);
        root.setPadding(new Insets(32));
        root.setAlignment(Pos.CENTER);
        root.getStyleClass().addAll("app-root", "modal-root");

        VBox heroPanel = new VBox(16);
        heroPanel.setPrefWidth(340);
        heroPanel.getStyleClass().addAll("surface-card", "hero-panel");
        heroPanel.getChildren().addAll(
                AppTheme.createHeaderBlock(
                        "LIBRARY PORTAL",
                        "Circulation, approvals, and analytics in one desktop workspace",
                        "Borrowers can request books, librarians can approve and issue them, and analytics stays visible without opening broken default dialogs."
                ),
                AppTheme.createChip("Users request books", "chip-neutral"),
                AppTheme.createChip("Librarians approve and issue", "chip-success"),
                AppTheme.createChip("Analytics and exports stay accessible", "chip-warning")
        );

        VBox formCard = new VBox(14);
        formCard.setPrefWidth(420);
        formCard.getStyleClass().addAll("surface-card");

        VBox formHeader = AppTheme.createHeaderBlock(
                "SIGN IN",
                "Access the library workspace",
                "Use your existing credentials or register a new librarian/user account."
        );
        formHeader.getStyleClass().add("compact-header");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        Label messageLabel = new Label();
        messageLabel.setWrapText(true);
        messageLabel.getStyleClass().add("muted-copy");

        ProgressIndicator loginProgress = new ProgressIndicator();
        loginProgress.setVisible(false);
        loginProgress.setMaxSize(28, 28);

        Button loginButton = createStyledButton("Login", BUTTON_STYLE_PRIMARY);
        loginButton.setDefaultButton(true);

        Button registerButton = createStyledButton("Register", BUTTON_STYLE_SUCCESS);

        HBox buttonRow = new HBox(10, registerButton, loginButton);
        buttonRow.setAlignment(Pos.CENTER_RIGHT);

        formCard.getChildren().addAll(formHeader, usernameField, passwordField, messageLabel, loginProgress, buttonRow);

        loginButton.setOnAction(e -> handleLogin(usernameField.getText(), passwordField.getText(), messageLabel, loginProgress));
        registerButton.setOnAction(e -> showRegistrationDialog());
        passwordField.setOnAction(e -> loginButton.fire());
        usernameField.setOnAction(e -> passwordField.requestFocus());

        root.getChildren().addAll(heroPanel, formCard);
        AppTheme.animateChildren(List.of(heroPanel, formCard), 0, 100);
        Platform.runLater(usernameField::requestFocus);
        return root;
    }

    /**
     * Handles user login with enhanced validation and error handling.
     */
    private void handleLogin(String username, String password, Label messageLabel,
                             ProgressIndicator progressIndicator) {

        clearMessage(messageLabel);

        if (username == null || username.trim().isEmpty()) {
            showErrorMessage(messageLabel, "Please enter your username.");
            return;
        }

        if (password == null || password.trim().isEmpty()) {
            showErrorMessage(messageLabel, "Please enter your password.");
            return;
        }

        // Show loading state
        progressIndicator.setVisible(true);
        messageLabel.setText("Authenticating...");
        messageLabel.setStyle("-fx-text-fill: blue; -fx-font-size: 12px;");

        // Perform login asynchronously
        CompletableFuture.supplyAsync(() -> {
            try {
                return UserService.login(username.trim(), password);
            } catch (Exception e) {
                System.err.println("Login failed for user: " + username + " - " + e.getMessage());
                return false;
            }
        }).thenAcceptAsync(success -> {
            Platform.runLater(() -> {
                progressIndicator.setVisible(false);

                if (success) {
                    currentUser = username.trim();
                    currentUserRole = UserService.getUserRole(currentUser);
                    showSuccessMessage(messageLabel, "Login successful! Loading dashboard...");

                    // Small delay to show success message
                    Timeline timeline = new Timeline(new KeyFrame(Duration.millis(1000), e -> showMainDashboard()));
                    timeline.play();
                } else {
                    showErrorMessage(messageLabel, "Invalid username or password. Please try again.");
                }
            });
        });
    }

    private void showRegistrationDialog() {
        RegistrationDialog.show(primaryStage, !UserService.hasRegisteredUsers()).ifPresent(request -> {
            try {
                UserService.createUser(request.username(), request.password(), request.role());
                UserService.persistDatabase();
                showSuccessAlert("Registration successful for " + request.username() + " as " + request.role().getDisplayName() + ".");
            } catch (Exception e) {
                showErrorAlert("Registration failed: " + e.getMessage());
            }
        });
    }

    /**
     * Shows the main dashboard with enhanced layout and functionality.
     */
    private void showMainDashboard() {
        currentUserRole = UserService.getUserRole(currentUser);
        BorderPane mainPane = new BorderPane();
        mainPane.getStyleClass().add("app-root");
        mainPane.setPadding(new Insets(18));

        HBox content = new HBox(18);
        content.setAlignment(Pos.TOP_LEFT);
        VBox booksSection = createBooksSection();
        VBox issueSection = createIssueRecordsSection();
        VBox analyticsSection = createAnalyticsSection();

        HBox.setHgrow(booksSection, Priority.ALWAYS);
        HBox.setHgrow(issueSection, Priority.ALWAYS);
        content.getChildren().addAll(booksSection, issueSection, analyticsSection);

        mainPane.setTop(createHeaderSection());
        mainPane.setCenter(content);
        mainPane.setBottom(createStatusBar());

        Scene mainScene = AppTheme.createScene(mainPane, 1600, 900);

        primaryStage.setScene(mainScene);
        primaryStage.setMaximized(true);

        refreshAllData();

        if (autoRefreshTimeline != null) {
            autoRefreshTimeline.stop();
        }
        autoRefreshTimeline = new Timeline(new KeyFrame(Duration.seconds(30), e -> refreshAllData()));
        autoRefreshTimeline.setCycleCount(Timeline.INDEFINITE);
        autoRefreshTimeline.play();

        AppTheme.animateChildren(List.of(mainPane.getTop(), content, mainPane.getBottom()), 0, 110);
    }

    /**
     * Creates the header section with user info and quick stats.
     */
    private HBox createHeaderSection() {
        HBox header = new HBox(18);
        header.setPadding(new Insets(20));
        header.getStyleClass().addAll("surface-card", "hero-panel");
        header.setAlignment(Pos.CENTER_LEFT);

        VBox userInfo = new VBox(4);
        User currentUserObj = UserService.getUserById(currentUser);
        String displayName = currentUserObj.getFullName();
        Label welcomeLabel = new Label("Welcome, " + displayName);
        welcomeLabel.getStyleClass().add("page-title");
        welcomeLabel.setStyle("-fx-font-size: 22px;");

        Label timeLabel = new Label(currentUserRole.getDisplayName() + " • Logged in at " + LocalDate.now().format(DATE_FORMATTER));
        timeLabel.getStyleClass().add("page-body");

        userInfo.getChildren().addAll(welcomeLabel, timeLabel);

        statisticsLabel = new Label("Loading statistics...");
        statisticsLabel.getStyleClass().add("page-body");
        statisticsLabel.setWrapText(true);
        statisticsLabel.setMaxWidth(540);

        HBox actionButtons = new HBox(10);
        Button refreshButton = createStyledButton("🔄 Refresh", BUTTON_STYLE_PRIMARY);
        refreshButton.setOnAction(e -> refreshAllData());
        Button settingsButton = createStyledButton("⚙️ Settings", BUTTON_STYLE_PRIMARY);
        settingsButton.setOnAction(e -> showSettingsDialog());
        Button logoutButton = createStyledButton("🚪 Logout", BUTTON_STYLE_DANGER);
        logoutButton.setOnAction(e -> handleLogout());
        actionButtons.getChildren().addAll(refreshButton, settingsButton, logoutButton);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        header.getChildren().addAll(userInfo, spacer, statisticsLabel, actionButtons);
        return header;
    }

    /**
     * Creates the books management section.
     */
    private VBox createBooksSection() {
        VBox booksSection = new VBox(14);
        booksSection.setPrefWidth(620);
        booksSection.getStyleClass().addAll("surface-card");

        Label sectionTitle = new Label(isStaffUser() ? "Books Management" : "Book Catalog");
        sectionTitle.getStyleClass().add("section-title");
        Label sectionSubtitle = new Label(isStaffUser()
                ? "Maintain inventory and issue approvals from the catalog view."
                : "Browse the catalog and submit requests for staff approval.");
        sectionSubtitle.getStyleClass().add("section-subtitle");

        HBox toolbar = new HBox(10);
        Button btnAdd = createStyledButton("➕ Add Book", BUTTON_STYLE_SUCCESS);
        Button btnUpdate = createStyledButton("✏️ Update Book", BUTTON_STYLE_PRIMARY);
        Button btnDelete = createStyledButton("🗑️ Delete Book", BUTTON_STYLE_DANGER);
        Button btnRefresh = createStyledButton("🔄 Refresh", BUTTON_STYLE_PRIMARY);

        btnAdd.setOnAction(e -> handleAddBook());
        btnUpdate.setOnAction(e -> handleUpdateBook());
        btnDelete.setOnAction(e -> handleDeleteBook());
        btnRefresh.setOnAction(e -> refreshAllData());
        configureStaffOnly(btnAdd);
        configureStaffOnly(btnUpdate);
        configureStaffOnly(btnDelete);
        toolbar.getChildren().addAll(btnAdd, btnUpdate, btnDelete, btnRefresh);

        searchField = new TextField();
        searchField.setPromptText("Search books by title, author, category, ISBN...");
        searchField.setMaxWidth(Double.MAX_VALUE);
        searchField.getStyleClass().add("search-field");

        booksListView = new ListView<>();
        filteredBooks = new FilteredList<>(booksList, b -> true);
        booksListView.setItems(filteredBooks);
        VBox.setVgrow(booksListView, Priority.ALWAYS);

        setupBooksListView();
        setupSearchFilter();

        Button btnIssue = createStyledButton(
                isStaffUser() ? "📖 Issue Book" : "📝 Request Book",
                isStaffUser() ? BUTTON_STYLE_SUCCESS : BUTTON_STYLE_PRIMARY
        );
        btnIssue.setOnAction(e -> {
            if (isStaffUser()) {
                handleIssueBook();
            } else {
                handleRequestBook();
            }
        });
        HBox issueActionRow = new HBox(btnIssue);
        issueActionRow.setAlignment(Pos.CENTER_RIGHT);

        booksSection.getChildren().addAll(sectionTitle, sectionSubtitle, toolbar, searchField, booksListView, issueActionRow);

        return booksSection;
    }

    /**
     * Creates the issue records section.
     */
    private VBox createIssueRecordsSection() {
        VBox issueSection = new VBox(14);
        issueSection.setPrefWidth(620);
        issueSection.getStyleClass().addAll("surface-card");

        Label sectionTitle = new Label(isStaffUser() ? "Loans and Requests" : "My Library Activity");
        sectionTitle.getStyleClass().add("section-title");
        Label sectionSubtitle = new Label(isStaffUser()
                ? "Approve demand, monitor overdue activity, and intervene when loans fall behind."
                : "Track active loans, overdue items, and the status of your requests.");
        sectionSubtitle.getStyleClass().add("section-subtitle");

        issueRecordsListView = new ListView<>();
        filteredIssueRecords = new FilteredList<>(issueRecordsList, r -> true);
        issueRecordsListView.setItems(filteredIssueRecords);
        VBox.setVgrow(issueRecordsListView, Priority.ALWAYS);

        setupIssueRecordsListView();

        Label issueListTitle = new Label(isStaffUser() ? "Issued Books" : "My Borrowed Books");
        issueListTitle.getStyleClass().add("metric-title");

        HBox buttons = new HBox(15);
        Button btnReturn = createStyledButton("↩️ Return Book", BUTTON_STYLE_DANGER);
        Button btnViewUser = createStyledButton("👤 View User", BUTTON_STYLE_PRIMARY);
        Button btnOverdueReport = createStyledButton("⚠️ Overdue Report", BUTTON_STYLE_WARNING);
        Button btnSendReminders = createStyledButton("📧 Send Reminders", "#8e44ad");

        btnReturn.setOnAction(e -> handleReturnBook());
        btnViewUser.setOnAction(e -> handleViewUserDetails());
        btnOverdueReport.setOnAction(e -> showOverdueReport());
        btnSendReminders.setOnAction(e -> sendReminders());
        configureStaffOnly(btnReturn);
        configureStaffOnly(btnViewUser);
        configureStaffOnly(btnSendReminders);

        buttons.getChildren().addAll(btnReturn, btnViewUser, btnOverdueReport, btnSendReminders);
        buttons.setAlignment(Pos.CENTER);

        Label requestListTitle = new Label(isStaffUser() ? "Borrow Requests" : "My Requests");
        requestListTitle.getStyleClass().add("metric-title");

        borrowRequestsListView = new ListView<>(borrowRequestsList);
        borrowRequestsListView.setPrefHeight(220);
        setupBorrowRequestsListView();

        HBox requestButtons = new HBox(15);
        Button btnApproveRequest = createStyledButton("✅ Approve Request", BUTTON_STYLE_SUCCESS);
        Button btnRejectRequest = createStyledButton("❌ Reject Request", BUTTON_STYLE_DANGER);
        Button btnRefreshRequests = createStyledButton("🔄 Refresh", BUTTON_STYLE_PRIMARY);
        btnApproveRequest.setOnAction(e -> handleApproveRequest());
        btnRejectRequest.setOnAction(e -> handleRejectRequest());
        btnRefreshRequests.setOnAction(e -> refreshAllData());
        configureStaffOnly(btnApproveRequest);
        configureStaffOnly(btnRejectRequest);
        requestButtons.getChildren().addAll(btnApproveRequest, btnRejectRequest, btnRefreshRequests);
        requestButtons.setAlignment(Pos.CENTER);

        issueSection.getChildren().addAll(
                sectionTitle,
                sectionSubtitle,
                issueListTitle,
                issueRecordsListView,
                buttons,
                new Separator(),
                requestListTitle,
                borrowRequestsListView,
                requestButtons
        );

        return issueSection;
    }

    private VBox createAnalyticsSection() {
        analyticsDashboard = new AnalyticsDashboard(this::showAnalyticsStudio);
        analyticsDashboard.setPrefWidth(420);
        return analyticsDashboard;
    }

    /**
     * Creates the status bar.
     */
    private HBox createStatusBar() {
        HBox statusBar = new HBox(10);
        statusBar.setPadding(new Insets(10, 16, 10, 16));
        statusBar.getStyleClass().addAll("surface-card");
        statusBar.setAlignment(Pos.CENTER_LEFT);

        statusLabel = new Label("Ready");
        statusLabel.getStyleClass().add("status-inline");

        loadingIndicator = new ProgressIndicator();
        loadingIndicator.setVisible(false);
        loadingIndicator.setMaxSize(16, 16);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label versionLabel = new Label("Version " + APP_VERSION);
        versionLabel.getStyleClass().add("muted-copy");

        statusBar.getChildren().addAll(statusLabel, loadingIndicator, spacer, versionLabel);

        return statusBar;
    }

    /**
     * Sets up the books list view with custom cell factory.
     */
    private void setupBooksListView() {
        booksListView.setCellFactory(lv -> new ListCell<Book>() {
            @Override
            protected void updateItem(Book book, boolean empty) {
                super.updateItem(book, empty);
                if (empty || book == null) {
                    setText(null);
                    setGraphic(null);
                    return;
                }

                int available = book.getQuantity();
                Label titleLabel = new Label(book.getTitle());
                titleLabel.getStyleClass().add("list-card-title");

                Label metaLabel = new Label(book.getAuthor() + " • " + book.getCategory());
                metaLabel.getStyleClass().add("list-card-meta");

                Label isbnLabel = new Label("ISBN " + book.getIsbn());
                isbnLabel.getStyleClass().add("list-card-meta");

                Label availabilityChip = AppTheme.createChip(
                        available > 0 ? available + " available" : "Out of stock",
                        available > 0 ? "chip-success" : "chip-danger"
                );

                Region spacer = new Region();
                HBox.setHgrow(spacer, Priority.ALWAYS);
                HBox topRow = new HBox(10, titleLabel, spacer, availabilityChip);
                topRow.setAlignment(Pos.CENTER_LEFT);

                VBox card = new VBox(6, topRow, metaLabel, isbnLabel);
                card.getStyleClass().addAll("list-card", available > 0 ? "list-card-success" : "list-card-danger");

                setGraphic(card);
                setText(null);
            }
        });
    }

    /**
     * Sets up the issue records list view with custom cell factory.
     */
    private void setupIssueRecordsListView() {
        issueRecordsListView.setCellFactory(lv -> new ListCell<IssueRecord>() {
            @Override
            protected void updateItem(IssueRecord record, boolean empty) {
                super.updateItem(record, empty);
                if (empty || record == null) {
                    setText(null);
                    setGraphic(null);
                    return;
                }

                String userInfo;
                try {
                    User user = UserService.getUserById(record.getUserId());
                    userInfo = user.getUserId() + (user.getEmail() != null ? " (" + user.getEmail() + ")" : "");
                } catch (Exception e) {
                    userInfo = record.getUserId();
                }

                Label titleLabel = new Label(record.getBookTitle());
                titleLabel.getStyleClass().add("list-card-title");

                Label borrowerLabel = new Label("Borrower: " + userInfo);
                borrowerLabel.getStyleClass().add("list-card-meta");

                String meta = String.format("Qty %d • Issued %s • Due %s",
                        record.getQuantity(), record.getIssueDate(), record.getDueDate());
                Label loanMetaLabel = new Label(meta);
                loanMetaLabel.getStyleClass().add("list-card-meta");

                Label statusChip = record.getDaysOverdue() > 0
                        ? AppTheme.createChip(record.getDaysOverdue() + " days overdue • $" + String.format("%.2f", record.calculateFine()), "chip-danger")
                        : AppTheme.createChip("On time", "chip-success");

                Region spacer = new Region();
                HBox.setHgrow(spacer, Priority.ALWAYS);
                HBox topRow = new HBox(10, titleLabel, spacer, statusChip);
                topRow.setAlignment(Pos.CENTER_LEFT);

                VBox card = new VBox(6, topRow, borrowerLabel, loanMetaLabel);
                card.getStyleClass().addAll("list-card", record.getDaysOverdue() > 0 ? "list-card-danger" : "list-card-success");

                setGraphic(card);
                setText(null);
            }
        });
    }

    private void setupBorrowRequestsListView() {
        borrowRequestsListView.setCellFactory(lv -> new ListCell<>() {
            @Override
            protected void updateItem(BorrowRequest request, boolean empty) {
                super.updateItem(request, empty);
                if (empty || request == null) {
                    setText(null);
                    setGraphic(null);
                    return;
                }

                Label titleLabel = new Label(request.getBookTitle());
                titleLabel.getStyleClass().add("list-card-title");

                String statusClass = switch (request.getStatus()) {
                    case APPROVED -> "chip-success";
                    case REJECTED -> "chip-danger";
                    default -> "chip-warning";
                };
                Label statusChip = AppTheme.createChip(request.getStatus().name(), statusClass);

                Label detailLabel = new Label("User " + request.getUserId()
                        + " • Qty " + request.getQuantity()
                        + " • Requested " + request.getRequestedAt().toLocalDate());
                detailLabel.getStyleClass().add("list-card-meta");

                String noteText = request.getNote() == null || request.getNote().isBlank()
                        ? "Awaiting staff action."
                        : request.getNote();
                String processedBy = request.getProcessedBy() == null ? "" : " • Processed by " + request.getProcessedBy();
                Label noteLabel = new Label(noteText + processedBy);
                noteLabel.getStyleClass().add("list-card-meta");
                noteLabel.setWrapText(true);

                Region spacer = new Region();
                HBox.setHgrow(spacer, Priority.ALWAYS);
                HBox topRow = new HBox(10, titleLabel, spacer, statusChip);
                topRow.setAlignment(Pos.CENTER_LEFT);

                String backgroundClass = switch (request.getStatus()) {
                    case APPROVED -> "list-card-success";
                    case REJECTED -> "list-card-danger";
                    default -> "list-card-warning";
                };
                VBox card = new VBox(6, topRow, detailLabel, noteLabel);
                card.getStyleClass().addAll("list-card", backgroundClass);

                setGraphic(card);
                setText(null);
            }
        });
    }

    /**
     * Sets up search filtering for books.
     */
    private void setupSearchFilter() {
        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            String filter = (newVal == null) ? "" : newVal.toLowerCase();
            filteredBooks.setPredicate(book -> {
                if (filter.isEmpty()) return true;
                return book.getTitle().toLowerCase().contains(filter)
                        || book.getAuthor().toLowerCase().contains(filter)
                        || book.getCategory().toLowerCase().contains(filter)
                        || book.getIsbn().toLowerCase().contains(filter);
            });
        });
    }

    /**
     * Refreshes all data asynchronously with loading indicators.
     */
    private void refreshAllData() {
        if (loadingIndicator != null) {
            loadingIndicator.setVisible(true);
            statusLabel.setText("Loading data...");
        }

        CompletableFuture.supplyAsync(() -> {
            try {
                Map<String, Object> data = new HashMap<>();
                data.put("books", BookService.getAllBooks());
                data.put("issueRecords", isStaffUser()
                        ? BookService.getAllActiveIssueRecords()
                        : BookService.getUserActiveIssueRecords(currentUser));
                data.put("borrowRequests", isStaffUser()
                        ? BookService.getAllBorrowRequests()
                        : BookService.getBorrowRequestsForUser(currentUser));
                data.put("statistics", BookService.getLibraryStatistics());
                return data;
            } catch (Exception e) {
                System.err.println("Failed to refresh data: " + e.getMessage());
                return new HashMap<String, Object>();
            }
        }).thenAcceptAsync(data -> {
            Platform.runLater(() -> {
                updateUIWithData(data);
                if (loadingIndicator != null) {
                    loadingIndicator.setVisible(false);
                    statusLabel.setText("Ready");
                }
            });
        });
    }

    @SuppressWarnings("unchecked")
    private void updateUIWithData(Map<String, Object> data) {
        try {
            // Update books list
            List<Book> books = (List<Book>) data.get("books");
            if (books != null) {
                booksList.setAll(books);
            }

            // Update issue records list
            List<IssueRecord> records = (List<IssueRecord>) data.get("issueRecords");
            if (records != null) {
                issueRecordsList.setAll(records);
            }

            List<BorrowRequest> requests = (List<BorrowRequest>) data.get("borrowRequests");
            if (requests != null) {
                borrowRequestsList.setAll(requests);
            }

            // Update statistics
            Map<String, Object> stats = (Map<String, Object>) data.get("statistics");
            if (stats != null) {
                updateStatisticsDisplay(stats);
            }

        } catch (Exception e) {
            System.err.println("Failed to update UI with data: " + e.getMessage());
            showErrorAlert("Failed to update display data: " + e.getMessage());
        }
    }

    private void updateStatisticsDisplay(Map<String, Object> stats) {
        try {
            String statsText = String.format(
                    "Titles %d | Available %d | Issued %d | Overdue %d | Requests %d | Fines $%.2f",
                    stats.get("totalBooks"),
                    stats.get("availableCopies"),
                    stats.get("issuedCopies"),
                    stats.get("overdueBooks"),
                    stats.get("pendingRequests"),
                    stats.get("totalFines")
            );
            statisticsLabel.setText(statsText);
            if (analyticsDashboard != null) {
                analyticsDashboard.update(stats, UserService.getUserCount(), getStaffCount());
            }
        } catch (Exception e) {
            statisticsLabel.setText("Statistics unavailable");
            System.err.println("Failed to format statistics: " + e.getMessage());
        }
    }

    // Event handlers for book management
    private void handleAddBook() {
        if (!requireStaffAccess("add books")) {
            return;
        }
        Optional<Book> result = showBookDialog("Add New Book", null);
        result.ifPresent(book -> {
            try {
                BookService.addBook(book);
                showSuccessAlert("Book added successfully.");
                refreshAllData();
            } catch (Exception e) {
                showErrorAlert("Failed to add book: " + e.getMessage());
            }
        });
    }

    private void handleUpdateBook() {
        if (!requireStaffAccess("update books")) {
            return;
        }
        Book selected = booksListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showErrorAlert("Please select a book to update.");
            return;
        }

        Optional<Book> result = showBookDialog("Update Book", selected);
        result.ifPresent(book -> {
            try {
                BookService.updateBook(book);
                showSuccessAlert("Book updated successfully.");
                refreshAllData();
            } catch (Exception e) {
                showErrorAlert("Failed to update book: " + e.getMessage());
            }
        });
    }

    private void handleDeleteBook() {
        if (!requireStaffAccess("delete books")) {
            return;
        }
        Book selected = booksListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showErrorAlert("Please select a book to delete.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION,
                "Are you sure you want to delete this book?\n" + selected.getTitle(),
                ButtonType.YES, ButtonType.NO);
        AppTheme.apply(alert.getDialogPane());
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                try {
                    BookService.deleteBook(selected.getIsbn());
                    showSuccessAlert("Book deleted successfully.");
                    refreshAllData();
                } catch (Exception e) {
                    showErrorAlert("Failed to delete book: " + e.getMessage());
                }
            }
        });
    }

    private void handleIssueBook() {
        if (!requireStaffAccess("issue books")) {
            return;
        }
        Book selected = booksListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showErrorAlert("Please select a book to issue.");
            return;
        }

        if (selected.getQuantity() <= 0) {
            showErrorAlert("This book is out of stock.");
            return;
        }

        showUserSelectionDialog("Select User to Issue Book")
                .ifPresent(user -> {
                    showQuantityDialog("Issue Copies", "How many copies to issue?", selected.getQuantity(), 1)
                            .ifPresent(quantity -> {
                                try {
                                    BookService.issueBookToUser(selected.getIsbn(), user.getUserId(), quantity);
                                    showSuccessAlert("Book issued successfully to " + user.getUserId());
                                    refreshAllData();
                                } catch (Exception e) {
                                    showErrorAlert("Failed to issue book: " + e.getMessage());
                                }
                            });
                });
    }

    private void handleReturnBook() {
        if (!requireStaffAccess("return books")) {
            return;
        }
        IssueRecord selected = issueRecordsListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showErrorAlert("Please select an issued book to return.");
            return;
        }

        showQuantityDialog("Return Copies", "How many copies to return?", selected.getQuantity(), selected.getQuantity())
                .ifPresent(quantity -> {
                    try {
                        BookService.returnBookFromUser(selected.getIsbn(), selected.getUserId(), quantity);
                        showSuccessAlert("Book returned successfully.");
                        refreshAllData();
                    } catch (Exception e) {
                        showErrorAlert("Failed to return book: " + e.getMessage());
                    }
                });
    }

    private void handleViewUserDetails() {
        if (!requireStaffAccess("view borrower details")) {
            return;
        }
        IssueRecord selected = issueRecordsListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showErrorAlert("Please select an issued book to view user details.");
            return;
        }

        try {
            User user = UserService.getUserById(selected.getUserId());
            String details = String.format(
                    "User Details:\n\n" +
                            "Username: %s\n" +
                            "Email: %s\n" +
                            "Contact: %s\n" +
                            "Books Borrowed: %d\n" +
                            "Outstanding Fines: $%.2f",
                    user.getUserId(),
                    user.getEmail() != null ? user.getEmail() : "Not provided",
                    user.getContactNumber() != null ? user.getContactNumber() : "Not provided",
                    BookService.getUserTotalBorrowedBooks(user.getUserId()),
                    BookService.getUserTotalFine(user.getUserId())
            );

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("User Details");
            alert.setHeaderText(null);
            alert.setContentText(details);
            AppTheme.apply(alert.getDialogPane());
            alert.showAndWait();
        } catch (Exception e) {
            showErrorAlert("Failed to load user details: " + e.getMessage());
        }
    }

    private void handleRequestBook() {
        Book selected = booksListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showErrorAlert("Please select a book to request.");
            return;
        }

        int maxRequest = Math.max(1, BookService.getMaxBorrowLimit());
        showQuantityDialog("Request Book", "How many copies do you want to request?", maxRequest, 1)
                .ifPresent(quantity -> {
                    try {
                        BookService.requestBookForUser(selected.getIsbn(), currentUser, quantity);
                        showSuccessAlert("Book request submitted successfully.");
                        refreshAllData();
                    } catch (Exception e) {
                        showErrorAlert("Failed to request book: " + e.getMessage());
                    }
                });
    }

    private void handleApproveRequest() {
        if (!requireStaffAccess("approve book requests")) {
            return;
        }

        BorrowRequest selected = borrowRequestsListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showErrorAlert("Please select a request to approve.");
            return;
        }
        if (!selected.isPending()) {
            showErrorAlert("Only pending requests can be approved.");
            return;
        }

        try {
            BookService.approveBorrowRequest(selected.getRequestId(), currentUser);
            showSuccessAlert("Borrow request approved and book issued.");
            refreshAllData();
        } catch (Exception e) {
            showErrorAlert("Failed to approve request: " + e.getMessage());
        }
    }

    private void handleRejectRequest() {
        if (!requireStaffAccess("reject book requests")) {
            return;
        }

        BorrowRequest selected = borrowRequestsListView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showErrorAlert("Please select a request to reject.");
            return;
        }
        if (!selected.isPending()) {
            showErrorAlert("Only pending requests can be rejected.");
            return;
        }

        TextInputDialog reasonDialog = new TextInputDialog("Unavailable or rejected by library staff");
        reasonDialog.setTitle("Reject Request");
        reasonDialog.setHeaderText("Provide a reason for rejection");
        reasonDialog.setContentText("Reason:");
        AppTheme.apply(reasonDialog.getDialogPane());
        reasonDialog.showAndWait().ifPresent(reason -> {
            try {
                BookService.rejectBorrowRequest(selected.getRequestId(), currentUser, reason);
                showSuccessAlert("Borrow request rejected.");
                refreshAllData();
            } catch (Exception e) {
                showErrorAlert("Failed to reject request: " + e.getMessage());
            }
        });
    }

    private void showOverdueReport() {
        List<IssueRecord> overdueBooks = isStaffUser()
                ? BookService.getAllOverdueBooks()
                : BookService.getUserOverdueBooks(currentUser);
        if (overdueBooks.isEmpty()) {
            showInfoAlert("No overdue books found.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Overdue Books Report");
        alert.setHeaderText("Found " + overdueBooks.size() + " overdue books");
        alert.setContentText(OverdueReportFormatter.format(overdueBooks));
        alert.getDialogPane().setPrefSize(500, 400);
        AppTheme.apply(alert.getDialogPane());
        alert.showAndWait();
    }

    private void sendReminders() {
        if (!requireStaffAccess("send reminder emails")) {
            return;
        }
        List<IssueRecord> overdueBooks = BookService.getAllOverdueBooks();
        if (overdueBooks.isEmpty()) {
            showInfoAlert("No overdue books. No reminders to send.");
            return;
        }
        try {
            ReminderService.ReminderDispatchResult result = ReminderService.sendOverdueReminders(overdueBooks);
            showInfoAlert(String.format(
                    "Reminder summary:\n\nSent: %d\nSkipped (missing email): %d\nFailures: %d",
                    result.getSentCount(),
                    result.getSkippedNoEmailCount(),
                    result.getFailures().size()
            ));
        } catch (Exception e) {
            showErrorAlert("Failed to send reminders: " + e.getMessage());
        }
    }

    // Dialog methods
    private Optional<Book> showBookDialog(String title, Book existingBook) {
        Dialog<Book> dialog = new Dialog<>();
        dialog.setTitle(title);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        AppTheme.apply(dialog.getDialogPane());

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        TextField isbnField = new TextField();
        TextField titleField = new TextField();
        TextField authorField = new TextField();
        TextField categoryField = new TextField();
        TextField quantityField = new TextField();

        if (existingBook != null) {
            isbnField.setText(existingBook.getIsbn());
            isbnField.setDisable(true);
            titleField.setText(existingBook.getTitle());
            authorField.setText(existingBook.getAuthor());
            categoryField.setText(existingBook.getCategory());
            quantityField.setText(String.valueOf(existingBook.getQuantity()));
        } else {
            isbnField.setPromptText("ISBN");
            titleField.setPromptText("Title");
            authorField.setPromptText("Author");
            categoryField.setPromptText("Category");
            quantityField.setPromptText("Quantity");
        }

        grid.addRow(0, new Label("ISBN:"), isbnField);
        grid.addRow(1, new Label("Title:"), titleField);
        grid.addRow(2, new Label("Author:"), authorField);
        grid.addRow(3, new Label("Category:"), categoryField);
        grid.addRow(4, new Label("Quantity:"), quantityField);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(button -> {
            if (button == ButtonType.OK) {
                try {
                    if (isbnField.getText().trim().isEmpty() ||
                            titleField.getText().trim().isEmpty() ||
                            authorField.getText().trim().isEmpty() ||
                            categoryField.getText().trim().isEmpty() ||
                            quantityField.getText().trim().isEmpty()) {
                        showErrorAlert("All fields are required.");
                        return null;
                    }

                    int quantity = Integer.parseInt(quantityField.getText().trim());
                    if (quantity < 0) {
                        showErrorAlert("Quantity cannot be negative.");
                        return null;
                    }

                    if (existingBook != null) {
                        existingBook.setTitle(titleField.getText().trim());
                        existingBook.setAuthor(authorField.getText().trim());
                        existingBook.setCategory(categoryField.getText().trim());
                        existingBook.setQuantity(quantity);
                        return existingBook;
                    } else {
                        return new Book(
                                isbnField.getText().trim(),
                                titleField.getText().trim(),
                                authorField.getText().trim(),
                                categoryField.getText().trim(),
                                quantity
                        );
                    }
                } catch (NumberFormatException e) {
                    showErrorAlert("Please enter a valid number for quantity.");
                    return null;
                } catch (Exception e) {
                    showErrorAlert("Error creating book: " + e.getMessage());
                    return null;
                }
            }
            return null;
        });

        return dialog.showAndWait();
    }

    private Optional<User> showUserSelectionDialog(String title) {
        List<User> allUsers = UserService.getAllUsers().stream()
                .filter(User::isActive)
                .collect(Collectors.toList());
        if (allUsers.isEmpty() && !isStaffUser()) {
            showErrorAlert("No active users found. Add users from Settings > Manage Users first.");
            return Optional.empty();
        }

        Dialog<User> dialog = new Dialog<>();
        dialog.setTitle(title);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        dialog.setResizable(true);
        AppTheme.apply(dialog.getDialogPane());

        VBox content = new VBox(10);
        content.setPadding(new Insets(10));

        TextField searchFieldUser = new TextField();
        searchFieldUser.setPromptText("Search users by name or ID...");

        ListView<User> userListView = new ListView<>();
        ObservableList<User> userObservableList = FXCollections.observableArrayList(allUsers);
        FilteredList<User> filteredUsers = new FilteredList<>(userObservableList, user -> true);
        userListView.setItems(filteredUsers);
        userListView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        userListView.setPrefHeight(200);

        // Set up the list cell factory to display user information
        userListView.setCellFactory(lv -> new ListCell<User>() {
            @Override
            protected void updateItem(User user, boolean empty) {
                super.updateItem(user, empty);
                if (empty || user == null) {
                    setText(null);
                } else {
                    String displayText = user.getUserId();
                    if (user.getEmail() != null && !user.getEmail().trim().isEmpty()) {
                        displayText += " (" + user.getEmail() + ")";
                    }
                    if (user.getContactNumber() != null && !user.getContactNumber().trim().isEmpty()) {
                        displayText += " - " + user.getContactNumber();
                    }
                    setText(displayText);
                }
            }
        });

        // Set up search filtering
        searchFieldUser.textProperty().addListener((obs, oldVal, newVal) -> {
            String filter = newVal == null ? "" : newVal.toLowerCase().trim();
            filteredUsers.setPredicate(user -> {
                if (filter.isEmpty()) return true;
                return user.getUserId().toLowerCase().contains(filter) ||
                        (user.getEmail() != null && user.getEmail().toLowerCase().contains(filter)) ||
                        (user.getContactNumber() != null && user.getContactNumber().toLowerCase().contains(filter));
            });
        });

        content.getChildren().addAll(
                new Label("Search and select a user:"),
                searchFieldUser,
                userListView
        );

        if (isStaffUser()) {
            Button createUserButton = createStyledButton("➕ Create User", BUTTON_STYLE_SUCCESS);
            createUserButton.setOnAction(e -> showQuickCreateUserDialog().ifPresent(newUser -> {
                userObservableList.setAll(UserService.getAllUsers().stream()
                        .filter(User::isActive)
                        .collect(Collectors.toList()));
                userListView.getSelectionModel().select(newUser);
            }));
            content.getChildren().add(createUserButton);
        }

        dialog.getDialogPane().setContent(content);

        // Set result converter
        dialog.setResultConverter(button -> {
            if (button == ButtonType.OK) {
                return userListView.getSelectionModel().getSelectedItem();
            }
            return null;
        });

        return dialog.showAndWait();
    }

    private Optional<User> showQuickCreateUserDialog() {
        return UserAccountDialogs.showQuickCreateUser(primaryStage);
    }

    private Optional<Integer> showQuantityDialog(String title, String content, int max, int defaultValue) {
        TextInputDialog dialog = new TextInputDialog(String.valueOf(defaultValue));
        dialog.setTitle(title);
        dialog.setHeaderText(content);
        dialog.setContentText("Quantity (1-" + max + "):");
        AppTheme.apply(dialog.getDialogPane());

        Optional<String> result = dialog.showAndWait();
        if (result.isPresent()) {
            try {
                int quantity = Integer.parseInt(result.get());
                if (quantity >= 1 && quantity <= max) {
                    return Optional.of(quantity);
                } else {
                    showErrorAlert("Quantity must be between 1 and " + max);
                }
            } catch (NumberFormatException e) {
                showErrorAlert("Please enter a valid number.");
            }
        }
        return Optional.empty();
    }

    private void showSettingsDialog() {
        SettingsWorkspace.show(primaryStage, currentUserRole, new SettingsWorkspace.Actions() {
            @Override
            public void openProfile() {
                showUserSettingsStage();
            }

            @Override
            public void openPassword() {
                showChangePasswordStage();
            }

            @Override
            public void openUserManagement() {
                showUserManagementDialog();
            }

            @Override
            public void openLibraryConfiguration() {
                showLibraryConfigDialog();
            }

            @Override
            public void openDataManagement() {
                showDataManagementDialog();
            }

            @Override
            public void openAnalytics() {
                showAnalyticsStudio();
            }
        });
    }

    private boolean showUserSettingsStage() {
        try {
            boolean updated = UserAccountDialogs.showProfileEditor(primaryStage, currentUser);
            if (updated) {
                showSuccessAlert("Profile updated successfully.");
                refreshHeaderInfo();
            }
            return updated;
        } catch (Exception e) {
            showErrorAlert("Failed to open profile editor: " + e.getMessage());
            return false;
        }
    }

    private boolean showChangePasswordStage() {
        try {
            boolean updated = UserAccountDialogs.showPasswordEditor(primaryStage, currentUser);
            if (updated) {
                showSuccessAlert("Password changed successfully.");
            }
            return updated;
        } catch (Exception e) {
            showErrorAlert("Failed to open password editor: " + e.getMessage());
            return false;
        }
    }

    private void showLibraryConfigDialog() {
        if (!requireStaffAccess("update library configuration")) {
            return;
        }

        AppConfiguration config = AppConfigurationService.getConfiguration();
        LibraryConfigurationDialog.show(
                primaryStage,
                config,
                BookService.getMaxBorrowLimit(),
                BookService.getLoanPeriodDays(),
                BookService.getFinePerDay()
        ).ifPresent(input -> {
            try {
                BookService.updateLibraryConfiguration(input.maxBorrowLimit(), input.loanDays(), input.finePerDay());

                AppConfiguration updated = AppConfigurationService.getConfiguration();
                updated.setExportDirectory(input.exportDirectory());
                updated.setSmtpHost(input.smtpHost());
                updated.setSmtpPort(input.smtpPort());
                updated.setSmtpUsername(input.smtpUsername());
                updated.setSmtpPassword(input.smtpPassword());
                updated.setFromAddress(input.fromAddress());
                updated.setSmtpAuth(input.smtpAuth());
                updated.setStartTlsEnabled(input.startTlsEnabled());
                AppConfigurationService.updateConfiguration(updated);

                showSuccessAlert("Library configuration updated successfully.");
                refreshAllData();
            } catch (Exception e) {
                showErrorAlert("Failed to update configuration: " + e.getMessage());
            }
        });
    }

    private void showDataManagementDialog() {
        if (!requireStaffAccess("manage library data")) {
            return;
        }

        Map<String, Object> stats = BookService.getLibraryStatistics();
        AppConfiguration config = AppConfigurationService.getConfiguration();

        DataManagementWorkspace.show(primaryStage,
                new DataManagementWorkspace.Snapshot(
                        ((Number) stats.getOrDefault("totalBooks", 0)).intValue(),
                        ((Number) stats.getOrDefault("totalCopies", 0)).intValue(),
                        ((Number) stats.getOrDefault("availableCopies", 0)).intValue(),
                        ((Number) stats.getOrDefault("issuedCopies", 0)).intValue(),
                        ((Number) stats.getOrDefault("overdueBooks", 0)).intValue(),
                        UserService.getUserCount(),
                        ((Number) stats.getOrDefault("pendingRequests", 0)).intValue(),
                        ((Number) stats.getOrDefault("totalFines", 0.0)).doubleValue(),
                        config.getExportDirectory(),
                        config.isEmailConfigured()
                ),
                new DataManagementWorkspace.Actions() {
                    @Override
                    public void createBackup() {
                        createBackupAsync();
                    }

                    @Override
                    public void exportReports() {
                        exportReports();
                    }

                    @Override
                    public void openAnalytics() {
                        showAnalyticsStudio();
                    }
                });
    }

    private void showUserManagementDialog() {
        if (!requireStaffAccess("manage users")) {
            return;
        }
        try {
            UserAccountDialogs.showUserManagement(primaryStage, currentUser);
        } catch (Exception e) {
            showErrorAlert("Failed to open user management: " + e.getMessage());
        }
    }

    private void showAnalyticsStudio() {
        AnalyticsDashboard.showStudio(primaryStage, BookService.getLibraryStatistics(), UserService.getUserCount(), getStaffCount());
    }

    private void createBackupAsync() {
        if (loadingIndicator != null) {
            loadingIndicator.setVisible(true);
            statusLabel.setText("Creating backup...");
        }

        CompletableFuture.supplyAsync(() -> {
            try {
                String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
                boolean success = true;

                success &= com.example.storage.DataStorage.createBackup("data/users_db.ser");
                success &= com.example.storage.DataStorage.createBackup("data/books_db.ser");
                success &= com.example.storage.DataStorage.createBackup("data/issued_books.ser");
                success &= com.example.storage.DataStorage.createBackup("data/borrower_details.ser");
                success &= com.example.storage.DataStorage.createBackup("data/issue_records.ser");
                success &= com.example.storage.DataStorage.createBackup("data/borrow_requests.ser");
                success &= com.example.storage.DataStorage.createBackup("data/app_config.ser");

                return Map.of("success", success, "timestamp", timestamp);
            } catch (Exception ex) {
                return Map.of("success", false, "error", ex.getMessage());
            }
        }).thenAcceptAsync(result -> Platform.runLater(() -> {
            if (loadingIndicator != null) {
                loadingIndicator.setVisible(false);
                statusLabel.setText("Ready");
            }

            Boolean success = (Boolean) result.get("success");
            if (success) {
                showSuccessAlert("Database backup created successfully.\n\nBackup timestamp: " + result.get("timestamp"));
            } else if (result.get("error") != null) {
                showErrorAlert("Backup failed: " + result.get("error"));
            } else {
                showErrorAlert("Some backup operations failed. Check the console for details.");
            }
        }));
    }

    private void exportReports() {
        try {
            Path overduePath = ReportExportService.exportOverdueReportCsv(BookService.getAllOverdueBooks());
            Path issuedPath = ReportExportService.exportIssuedBooksCsv(BookService.getAllActiveIssueRecords());
            Path requestPath = ReportExportService.exportBorrowRequestsCsv(BookService.getAllBorrowRequests());
            showSuccessAlert("Reports exported successfully:\n\n" + overduePath + "\n" + issuedPath + "\n" + requestPath);
        } catch (Exception e) {
            showErrorAlert("Failed to export reports: " + e.getMessage());
        }
    }

    /**
     * Refreshes the header information to show updated user details.
     */
    private void refreshHeaderInfo() {
        try {
            User updatedUser = UserService.getUserById(currentUser);

            // Find the welcome label in the header and update it
            BorderPane mainPane = (BorderPane) primaryStage.getScene().getRoot();
            HBox header = (HBox) mainPane.getTop();
            VBox userInfo = (VBox) header.getChildren().get(0);
            Label welcomeLabel = (Label) userInfo.getChildren().get(0);
            Label subtitleLabel = (Label) userInfo.getChildren().get(1);

            String displayName = updatedUser.getFullName();
            welcomeLabel.setText("Welcome, " + displayName);
            subtitleLabel.setText(updatedUser.getRole().getDisplayName() + " • Logged in at " +
                    LocalDate.now().format(DATE_FORMATTER));

        } catch (Exception e) {
            System.err.println("Failed to refresh header info: " + e.getMessage());
        }
    }

    // === FIXED SETTINGS MODULE END ===

    private boolean isStaffUser() {
        return currentUserRole != null && currentUserRole.isStaff();
    }

    private int getStaffCount() {
        return (int) UserService.getAllUsers().stream()
                .filter(User::isStaff)
                .count();
    }

    private boolean requireStaffAccess(String capability) {
        if (isStaffUser()) {
            return true;
        }
        showErrorAlert("Only librarians or administrators can " + capability + ".");
        return false;
    }

    private void configureStaffOnly(Button button) {
        if (!isStaffUser()) {
            button.setManaged(false);
            button.setVisible(false);
        }
    }

    // Utility methods for UI components
    private Button createStyledButton(String text, String style) {
        AppTheme.ButtonTone tone;
        if (BUTTON_STYLE_SUCCESS.equals(style)) {
            tone = AppTheme.ButtonTone.SUCCESS;
        } else if (BUTTON_STYLE_DANGER.equals(style)) {
            tone = AppTheme.ButtonTone.DANGER;
        } else if (BUTTON_STYLE_WARNING.equals(style)) {
            tone = AppTheme.ButtonTone.WARNING;
        } else if ("#8e44ad".equals(style)) {
            tone = AppTheme.ButtonTone.SECONDARY;
        } else {
            tone = AppTheme.ButtonTone.PRIMARY;
        }
        return AppTheme.createButton(text, tone);
    }

    private void showErrorMessage(Label messageLabel, String message) {
        messageLabel.setText(message);
        messageLabel.setStyle("-fx-text-fill: #a94438;");
    }

    private void showSuccessMessage(Label messageLabel, String message) {
        messageLabel.setText(message);
        messageLabel.setStyle("-fx-text-fill: #196140;");
    }

    private void clearMessage(Label messageLabel) {
        messageLabel.setText("");
    }

    // FIXED ALERT METHODS - These now properly handle rendering issues
    /**
     * FIXED: Shows error alert with proper threading and sizing.
     */
    private void showErrorAlert(String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initOwner(primaryStage);
            alert.setTitle("Error");
            alert.setHeaderText("An Error Occurred");
            alert.setContentText(message);
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.getDialogPane().setMinWidth(Region.USE_PREF_SIZE);
            alert.getDialogPane().setPrefWidth(450);
            alert.setResizable(true);
            AppTheme.apply(alert.getDialogPane());
            alert.getDialogPane().autosize();
            alert.showAndWait();
        });
    }

    /**
     * FIXED: Shows success alert with proper threading and sizing.
     */
    private void showSuccessAlert(String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initOwner(primaryStage);
            alert.setTitle("Success");
            alert.setHeaderText("Operation Completed Successfully");
            alert.setContentText(message);
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.getDialogPane().setMinWidth(Region.USE_PREF_SIZE);
            alert.getDialogPane().setPrefWidth(450);
            alert.setResizable(true);
            AppTheme.apply(alert.getDialogPane());
            alert.getDialogPane().autosize();
            alert.showAndWait();
        });
    }

    /**
     * FIXED: Shows info alert with proper threading and sizing.
     */
    private void showInfoAlert(String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initOwner(primaryStage);
            alert.setTitle("Information");
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            alert.getDialogPane().setMinWidth(Region.USE_PREF_SIZE);
            alert.getDialogPane().setPrefWidth(450);
            alert.setResizable(true);
            AppTheme.apply(alert.getDialogPane());
            alert.getDialogPane().autosize();
            alert.showAndWait();
        });
    }

    private void handleLogout() {
        if (autoRefreshTimeline != null) {
            autoRefreshTimeline.stop();
        }
        currentUser = null;
        currentUserRole = UserRole.USER;
        showLoginScreen();
    }

    /**
     * Handles application shutdown with proper cleanup.
     */
    private void handleApplicationClose() {
        try {
            UserService.persistDatabase();
            BorrowRequestService.persist();
            System.out.println("Application closed gracefully by user: " + currentUser);
        } catch (Exception e) {
            System.err.println("Error during application shutdown: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
