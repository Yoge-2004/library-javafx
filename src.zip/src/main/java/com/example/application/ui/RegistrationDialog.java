package com.example.application.ui;

import com.example.entities.UserRole;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;

public final class RegistrationDialog {

    public record RegistrationRequest(String username, String password, UserRole role) {
    }

    private RegistrationDialog() {
    }

    public static Optional<RegistrationRequest> show(Stage owner, boolean firstAccount) {
        Stage stage = AppTheme.createModalStage(owner, "Create Account", 980, 640);
        AtomicReference<RegistrationRequest> result = new AtomicReference<>();

        HBox root = new HBox(24);
        root.setPadding(new Insets(28));
        root.setAlignment(Pos.CENTER);
        root.getStyleClass().addAll("app-root", "modal-root");

        VBox hero = new VBox(16);
        hero.setPrefWidth(320);
        hero.getStyleClass().addAll("surface-card", "hero-panel");

        VBox heroHeader = AppTheme.createHeaderBlock(
                "SELF-SERVICE REGISTRATION",
                "Create a modern library account",
                "Users can request books. Librarians can review requests, issue loans, and manage inventory. The first account is automatically promoted to administrator so the system always has an owner."
        );

        Label roleSummary = new Label(firstAccount
                ? "Bootstrap mode: this account becomes Administrator."
                : "Choose User for self-service borrowing or Librarian for staff operations.");
        roleSummary.getStyleClass().add("page-body");
        roleSummary.setWrapText(true);

        VBox roleList = new VBox(10,
                AppTheme.createChip("User", "chip-neutral"),
                AppTheme.createChip("Librarian", "chip-success"),
                AppTheme.createChip(firstAccount ? "Administrator" : "Approval Workflow", "chip-warning")
        );

        hero.getChildren().addAll(heroHeader, roleSummary, roleList);

        VBox formCard = new VBox(16);
        formCard.setPrefWidth(420);
        formCard.getStyleClass().addAll("surface-card");

        VBox formHeader = AppTheme.createHeaderBlock(
                "ACCOUNT FORM",
                "Register new access",
                "Keep usernames short and stable. Passwords must be at least four characters."
        );
        formHeader.getStyleClass().add("compact-header");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Confirm password");

        ToggleButton userButton = new ToggleButton("User");
        ToggleButton librarianButton = new ToggleButton("Librarian");
        userButton.getStyleClass().add("role-card");
        librarianButton.getStyleClass().add("role-card");

        ToggleGroup toggleGroup = new ToggleGroup();
        userButton.setToggleGroup(toggleGroup);
        librarianButton.setToggleGroup(toggleGroup);
        userButton.setSelected(true);

        HBox roleBox = new HBox(10, userButton, librarianButton);
        if (firstAccount) {
            userButton.setDisable(true);
            librarianButton.setDisable(true);
        }

        Label roleLabel = new Label(firstAccount ? "Role is locked to Administrator for the first account." : "Choose the new account role.");
        roleLabel.getStyleClass().add("muted-copy");
        roleLabel.setWrapText(true);

        Label validationLabel = new Label();
        validationLabel.setWrapText(true);
        validationLabel.getStyleClass().add("muted-copy");

        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        Button cancelButton = AppTheme.createButton("Cancel", AppTheme.ButtonTone.GHOST);
        Button createButton = AppTheme.createButton("Create Account", AppTheme.ButtonTone.SUCCESS);

        HBox buttonRow = new HBox(10, cancelButton, createButton);
        buttonRow.setAlignment(Pos.CENTER_RIGHT);

        formCard.getChildren().addAll(
                formHeader,
                usernameField,
                passwordField,
                confirmPasswordField,
                roleLabel,
                roleBox,
                validationLabel,
                spacer,
                buttonRow
        );

        cancelButton.setOnAction(event -> stage.close());
        createButton.setOnAction(event -> {
            String username = usernameField.getText() == null ? "" : usernameField.getText().trim();
            String password = passwordField.getText() == null ? "" : passwordField.getText();
            String confirmPassword = confirmPasswordField.getText() == null ? "" : confirmPasswordField.getText();

            if (username.isEmpty() || password.isEmpty()) {
                validationLabel.setText("Username and password are required.");
                return;
            }
            if (!password.equals(confirmPassword)) {
                validationLabel.setText("Passwords do not match.");
                return;
            }

            UserRole role = firstAccount
                    ? UserRole.ADMIN
                    : (toggleGroup.getSelectedToggle() == librarianButton ? UserRole.LIBRARIAN : UserRole.USER);
            result.set(new RegistrationRequest(username, password, role));
            stage.close();
        });

        Scene scene = AppTheme.createScene(root, 980, 640);
        root.getChildren().addAll(hero, formCard);
        AppTheme.animateChildren(List.of(hero, formCard), 0, 100);
        stage.setScene(scene);
        stage.showAndWait();

        return Optional.ofNullable(result.get());
    }
}
