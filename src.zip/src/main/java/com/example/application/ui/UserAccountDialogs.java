package com.example.application.ui;

import com.example.entities.User;
import com.example.entities.UserRole;
import com.example.services.UserService;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;

public final class UserAccountDialogs {

    private UserAccountDialogs() {
    }

    public static boolean showProfileEditor(Stage owner, String currentUserId) {
        Stage stage = AppTheme.createModalStage(owner, "Profile Details", 780, 620);
        AtomicReference<Boolean> updated = new AtomicReference<>(false);

        User currentUser = UserService.getUserById(currentUserId);

        BorderPane root = new BorderPane();
        root.getStyleClass().addAll("app-root", "modal-root");
        root.setPadding(new Insets(24));

        VBox hero = AppTheme.createHeaderBlock(
                "PROFILE",
                "Maintain borrower details",
                "Update personal details used by circulation staff and reminder workflows."
        );
        hero.getStyleClass().addAll("surface-card", "hero-panel");

        VBox form = new VBox(14);
        form.getStyleClass().addAll("surface-card");

        TextField usernameField = new TextField(currentUser.getUserId());
        usernameField.setDisable(true);

        TextField firstNameField = new TextField(Optional.ofNullable(currentUser.getFirstName()).orElse(""));
        firstNameField.setPromptText("First name");
        TextField lastNameField = new TextField(Optional.ofNullable(currentUser.getLastName()).orElse(""));
        lastNameField.setPromptText("Last name");
        TextField emailField = new TextField(Optional.ofNullable(currentUser.getEmail()).orElse(""));
        emailField.setPromptText("Email address");
        TextField contactField = new TextField(Optional.ofNullable(currentUser.getContactNumber()).orElse(""));
        contactField.setPromptText("Contact number");

        Label validationLabel = new Label();
        validationLabel.setWrapText(true);
        validationLabel.getStyleClass().add("muted-copy");

        Button cancelButton = AppTheme.createButton("Cancel", AppTheme.ButtonTone.GHOST);
        Button saveButton = AppTheme.createButton("Save Profile", AppTheme.ButtonTone.SUCCESS);
        cancelButton.setOnAction(event -> stage.close());
        saveButton.setOnAction(event -> {
            String emailText = emailField.getText().trim();
            String contactText = contactField.getText().trim();

            if (!emailText.isEmpty() && !User.isValidEmail(emailText)) {
                validationLabel.setText("Email format is invalid.");
                return;
            }
            if (!contactText.isEmpty() && !User.isValidContactNumber(contactText)) {
                validationLabel.setText("Contact number format is invalid.");
                return;
            }

            try {
                currentUser.setFirstName(firstNameField.getText().trim().isEmpty() ? null : firstNameField.getText().trim());
                currentUser.setLastName(lastNameField.getText().trim().isEmpty() ? null : lastNameField.getText().trim());
                currentUser.setEmail(emailText.isEmpty() ? null : emailText);
                currentUser.setContactNumber(contactText.isEmpty() ? null : contactText);
                UserService.updateUser(currentUser);
                UserService.persistDatabase();
                updated.set(true);
                stage.close();
            } catch (Exception exception) {
                validationLabel.setText("Profile update failed: " + exception.getMessage());
            }
        });

        HBox buttonRow = new HBox(10, cancelButton, saveButton);
        buttonRow.setAlignment(Pos.CENTER_RIGHT);

        form.getChildren().addAll(
                fieldGroup("Username", usernameField),
                fieldGroup("First name", firstNameField),
                fieldGroup("Last name", lastNameField),
                fieldGroup("Email address", emailField),
                fieldGroup("Contact number", contactField),
                validationLabel,
                buttonRow
        );

        HBox content = new HBox(18, hero, form);
        HBox.setHgrow(form, Priority.ALWAYS);
        hero.setPrefWidth(260);

        root.setCenter(content);

        Scene scene = AppTheme.createScene(root, 780, 620);
        stage.setScene(scene);
        AppTheme.animateChildren(List.of(hero, form), 0, 100);
        stage.showAndWait();

        return updated.get();
    }

    public static boolean showPasswordEditor(Stage owner, String currentUserId) {
        Stage stage = AppTheme.createModalStage(owner, "Change Password", 740, 520);
        AtomicReference<Boolean> updated = new AtomicReference<>(false);

        BorderPane root = new BorderPane();
        root.getStyleClass().addAll("app-root", "modal-root");
        root.setPadding(new Insets(24));

        VBox header = AppTheme.createHeaderBlock(
                "SECURITY",
                "Rotate the current password",
                "Use a stronger password when the app is shared across circulation desks or staff shifts."
        );
        header.getStyleClass().addAll("surface-card", "hero-panel");

        VBox form = new VBox(14);
        form.getStyleClass().addAll("surface-card");

        PasswordField currentPasswordField = new PasswordField();
        currentPasswordField.setPromptText("Current password");
        PasswordField newPasswordField = new PasswordField();
        newPasswordField.setPromptText("New password");
        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Confirm password");

        Label strengthLabel = new Label();
        strengthLabel.getStyleClass().add("muted-copy");

        Label validationLabel = new Label();
        validationLabel.setWrapText(true);
        validationLabel.getStyleClass().add("muted-copy");

        newPasswordField.textProperty().addListener((obs, oldValue, newValue) ->
                strengthLabel.setText("Strength: " + getPasswordStrength(newValue))
        );

        Button cancelButton = AppTheme.createButton("Cancel", AppTheme.ButtonTone.GHOST);
        Button saveButton = AppTheme.createButton("Update Password", AppTheme.ButtonTone.WARNING);
        cancelButton.setOnAction(event -> stage.close());
        saveButton.setOnAction(event -> {
            try {
                String currentPassword = currentPasswordField.getText();
                String newPassword = newPasswordField.getText();
                String confirmPassword = confirmPasswordField.getText();

                if (currentPassword == null || currentPassword.isBlank()) {
                    validationLabel.setText("Current password is required.");
                    return;
                }
                if (newPassword == null || newPassword.isBlank()) {
                    validationLabel.setText("New password is required.");
                    return;
                }
                if (!newPassword.equals(confirmPassword)) {
                    validationLabel.setText("New passwords do not match.");
                    return;
                }
                if (!UserService.login(currentUserId, currentPassword)) {
                    validationLabel.setText("Current password is incorrect.");
                    return;
                }
                if (!User.isValidPassword(newPassword)) {
                    validationLabel.setText("New password must be at least four characters.");
                    return;
                }
                if (newPassword.equals(currentPassword)) {
                    validationLabel.setText("New password must be different from the current password.");
                    return;
                }

                User user = UserService.getUserById(currentUserId);
                user.setPassword(newPassword);
                user.updateLastLogin();
                UserService.updateUser(user);
                UserService.persistDatabase();
                updated.set(true);
                stage.close();
            } catch (Exception exception) {
                validationLabel.setText("Password update failed: " + exception.getMessage());
            }
        });

        HBox buttonRow = new HBox(10, cancelButton, saveButton);
        buttonRow.setAlignment(Pos.CENTER_RIGHT);

        form.getChildren().addAll(
                fieldGroup("Current password", currentPasswordField),
                fieldGroup("New password", newPasswordField),
                fieldGroup("Confirm password", confirmPasswordField),
                strengthLabel,
                validationLabel,
                buttonRow
        );

        HBox content = new HBox(18, header, form);
        header.setPrefWidth(240);
        HBox.setHgrow(form, Priority.ALWAYS);
        root.setCenter(content);

        Scene scene = AppTheme.createScene(root, 740, 520);
        stage.setScene(scene);
        AppTheme.animateChildren(List.of(header, form), 0, 100);
        stage.showAndWait();

        return updated.get();
    }

    public static void showUserManagement(Stage owner, String currentUserId) {
        Stage stage = AppTheme.createModalStage(owner, "User Management", 1100, 720);

        BorderPane root = new BorderPane();
        root.getStyleClass().addAll("app-root", "modal-root");
        root.setPadding(new Insets(24));

        HBox toolbar = new HBox(12);
        toolbar.setAlignment(Pos.CENTER_LEFT);

        VBox header = AppTheme.createHeaderBlock(
                "USER MANAGEMENT",
                "Create and govern library accounts",
                "Staff can create users on the fly, assign roles, disable accounts, and remove accounts that are no longer valid."
        );
        header.getStyleClass().add("compact-header");

        Button closeButton = AppTheme.createButton("Close", AppTheme.ButtonTone.GHOST);
        closeButton.setOnAction(event -> stage.close());
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        toolbar.getChildren().addAll(header, spacer, closeButton);

        ListView<User> usersView = new ListView<>();
        usersView.setItems(FXCollections.observableArrayList(UserService.getAllUsers()));
        usersView.setCellFactory(listView -> new ListCell<>() {
            @Override
            protected void updateItem(User user, boolean empty) {
                super.updateItem(user, empty);
                if (empty || user == null) {
                    setGraphic(null);
                    setText(null);
                    return;
                }

                Label nameLabel = new Label(user.getDisplayName());
                nameLabel.getStyleClass().add("list-card-title");
                Label metaLabel = new Label(user.getRole().getDisplayName()
                        + " • "
                        + (user.isActive() ? "Active" : "Disabled")
                        + " • "
                        + (user.getEmail() == null ? "No email" : user.getEmail()));
                metaLabel.getStyleClass().add("list-card-meta");

                VBox card = new VBox(4, nameLabel, metaLabel);
                card.getStyleClass().addAll("list-card", user.isActive() ? "list-card-success" : "list-card-warning");
                setGraphic(card);
                setText(null);
            }
        });

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Temporary password");
        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        ChoiceBox<UserRole> roleChoice = new ChoiceBox<>(FXCollections.observableArrayList(UserRole.values()));
        roleChoice.setValue(UserRole.USER);

        Label validationLabel = new Label();
        validationLabel.setWrapText(true);
        validationLabel.getStyleClass().add("muted-copy");

        Button addUserButton = AppTheme.createButton("Create User", AppTheme.ButtonTone.SUCCESS);
        addUserButton.setOnAction(event -> {
            try {
                UserService.createUser(usernameField.getText().trim(), passwordField.getText(), roleChoice.getValue());
                User created = UserService.getUserById(usernameField.getText().trim());
                created.setEmail(emailField.getText().trim().isEmpty() ? null : emailField.getText().trim());
                UserService.updateUser(created);
                UserService.persistDatabase();
                validationLabel.setText("User created successfully.");
                refreshUsers(usersView);
                usernameField.clear();
                passwordField.clear();
                emailField.clear();
                roleChoice.setValue(UserRole.USER);
            } catch (Exception exception) {
                validationLabel.setText("Failed to create user: " + exception.getMessage());
            }
        });

        Button toggleButton = AppTheme.createButton("Enable / Disable", AppTheme.ButtonTone.WARNING);
        toggleButton.setOnAction(event -> {
            User selected = usersView.getSelectionModel().getSelectedItem();
            if (selected == null) {
                validationLabel.setText("Select a user first.");
                return;
            }
            try {
                selected.setActive(!selected.isActive());
                UserService.updateUser(selected);
                UserService.persistDatabase();
                validationLabel.setText("User status updated.");
                refreshUsers(usersView);
            } catch (Exception exception) {
                validationLabel.setText("Failed to update status: " + exception.getMessage());
            }
        });

        Button deleteButton = AppTheme.createButton("Delete User", AppTheme.ButtonTone.DANGER);
        deleteButton.setOnAction(event -> {
            User selected = usersView.getSelectionModel().getSelectedItem();
            if (selected == null) {
                validationLabel.setText("Select a user first.");
                return;
            }
            if (selected.getUserId().equals(currentUserId)) {
                validationLabel.setText("You cannot delete the account you are currently using.");
                return;
            }
            try {
                UserService.deleteUser(selected.getUserId());
                UserService.persistDatabase();
                validationLabel.setText("User deleted.");
                refreshUsers(usersView);
            } catch (Exception exception) {
                validationLabel.setText("Failed to delete user: " + exception.getMessage());
            }
        });

        VBox rightRail = new VBox(14,
                AppTheme.createHeaderBlock(
                        "CREATE OR MANAGE",
                        "Identity operations",
                        "Create staff or borrower accounts, then review or change their state from the same surface."
                ),
                fieldGroup("Username", usernameField),
                fieldGroup("Temporary password", passwordField),
                fieldGroup("Email", emailField),
                fieldGroup("Role", roleChoice),
                validationLabel,
                addUserButton,
                toggleButton,
                deleteButton
        );
        rightRail.getStyleClass().addAll("surface-card");
        rightRail.setPrefWidth(300);

        VBox listCard = new VBox(12,
                AppTheme.createHeaderBlock(
                        "DIRECTORY",
                        "Current accounts",
                        "Select an account to disable or remove it. Disabled accounts remain visible for audit purposes."
                ),
                usersView
        );
        listCard.getStyleClass().addAll("surface-card");
        VBox.setVgrow(usersView, Priority.ALWAYS);
        HBox.setHgrow(listCard, Priority.ALWAYS);

        HBox content = new HBox(18, listCard, rightRail);

        root.setTop(toolbar);
        root.setCenter(content);

        Scene scene = AppTheme.createScene(root, 1100, 720);
        stage.setScene(scene);
        AppTheme.animateChildren(List.of(toolbar, listCard, rightRail), 0, 90);
        stage.showAndWait();
    }

    public static Optional<User> showQuickCreateUser(Stage owner) {
        Stage stage = AppTheme.createModalStage(owner, "Create User", 720, 520);
        AtomicReference<User> result = new AtomicReference<>();

        BorderPane root = new BorderPane();
        root.getStyleClass().addAll("app-root", "modal-root");
        root.setPadding(new Insets(24));

        VBox header = AppTheme.createHeaderBlock(
                "QUICK CREATE",
                "Create a borrower while issuing a book",
                "Use this shortcut when a walk-in patron needs an account before staff can complete issue approval."
        );
        header.getStyleClass().addAll("surface-card", "hero-panel");

        VBox form = new VBox(14);
        form.getStyleClass().addAll("surface-card");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        ChoiceBox<UserRole> roleChoice = new ChoiceBox<>(FXCollections.observableArrayList(UserRole.USER, UserRole.LIBRARIAN));
        roleChoice.setValue(UserRole.USER);

        Label validationLabel = new Label();
        validationLabel.setWrapText(true);
        validationLabel.getStyleClass().add("muted-copy");

        Button cancelButton = AppTheme.createButton("Cancel", AppTheme.ButtonTone.GHOST);
        Button createButton = AppTheme.createButton("Create User", AppTheme.ButtonTone.SUCCESS);
        cancelButton.setOnAction(event -> stage.close());
        createButton.setOnAction(event -> {
            try {
                UserService.createUser(usernameField.getText().trim(), passwordField.getText(), roleChoice.getValue());
                User created = UserService.getUserById(usernameField.getText().trim());
                created.setEmail(emailField.getText().trim().isEmpty() ? null : emailField.getText().trim());
                UserService.updateUser(created);
                UserService.persistDatabase();
                result.set(created);
                stage.close();
            } catch (Exception exception) {
                validationLabel.setText("Failed to create user: " + exception.getMessage());
            }
        });

        HBox buttons = new HBox(10, cancelButton, createButton);
        buttons.setAlignment(Pos.CENTER_RIGHT);

        form.getChildren().addAll(
                fieldGroup("Username", usernameField),
                fieldGroup("Password", passwordField),
                fieldGroup("Email", emailField),
                fieldGroup("Role", roleChoice),
                validationLabel,
                buttons
        );

        HBox content = new HBox(18, header, form);
        header.setPrefWidth(240);
        HBox.setHgrow(form, Priority.ALWAYS);
        root.setCenter(content);

        Scene scene = AppTheme.createScene(root, 720, 520);
        stage.setScene(scene);
        AppTheme.animateChildren(List.of(header, form), 0, 100);
        stage.showAndWait();

        return Optional.ofNullable(result.get());
    }

    private static VBox fieldGroup(String labelText, javafx.scene.Node node) {
        Label label = new Label(labelText);
        label.getStyleClass().add("metric-title");
        return new VBox(6, label, node);
    }

    private static String getPasswordStrength(String password) {
        if (password == null || password.length() < 4) {
            return "Weak";
        }

        int score = 0;
        if (password.length() >= 8) score++;
        if (password.length() >= 12) score++;
        if (password.matches(".*[a-z].*")) score++;
        if (password.matches(".*[A-Z].*")) score++;
        if (password.matches(".*[0-9].*")) score++;
        if (password.matches(".*[!@#$%^&*()_+=\\-\\[\\]{};':\"\\\\|,./<>/?].*")) score++;

        if (score <= 2) {
            return "Weak";
        }
        if (score <= 4) {
            return "Medium";
        }
        return "Strong";
    }

    private static void refreshUsers(ListView<User> usersView) {
        usersView.getItems().setAll(UserService.getAllUsers());
    }

    @SuppressWarnings("unused")
    private static void showAlert(Stage owner, Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        if (owner != null) {
            alert.initOwner(owner);
        }
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        AppTheme.apply(alert.getDialogPane());
        alert.showAndWait();
    }
}
