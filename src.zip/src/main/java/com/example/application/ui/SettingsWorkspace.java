package com.example.application.ui;

import com.example.entities.UserRole;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public final class SettingsWorkspace {

    public interface Actions {
        void openProfile();
        void openPassword();
        void openUserManagement();
        void openLibraryConfiguration();
        void openDataManagement();
        void openAnalytics();
    }

    private SettingsWorkspace() {
    }

    public static void show(Stage owner, UserRole role, Actions actions) {
        Stage stage = AppTheme.createModalStage(owner, "Settings", 1040, 700);

        BorderPane root = new BorderPane();
        root.getStyleClass().addAll("app-root", "modal-root");
        root.setPadding(new Insets(24));

        HBox toolbar = new HBox(12);
        toolbar.setAlignment(Pos.CENTER_LEFT);

        VBox header = AppTheme.createHeaderBlock(
                "SETTINGS WORKSPACE",
                "Account and operational controls",
                "Profile, security, configuration, analytics, and governance tasks now live in a single workspace instead of stacked default dialogs."
        );
        header.getStyleClass().add("compact-header");

        Button closeButton = AppTheme.createButton("Close", AppTheme.ButtonTone.GHOST);
        closeButton.setOnAction(event -> stage.close());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        toolbar.getChildren().addAll(header, spacer, closeButton);

        Label roleChip = AppTheme.createChip("Signed in as " + role.getDisplayName(), role.isStaff() ? "chip-success" : "chip-neutral");

        List<VBox> cards = new ArrayList<>();

        Button profileButton = AppTheme.createButton("Edit Profile", AppTheme.ButtonTone.PRIMARY);
        profileButton.setOnAction(event -> {
            stage.close();
            actions.openProfile();
        });
        cards.add(AppTheme.createActionCard(
                "ACCOUNT",
                "Profile details",
                "Update your name, email, and contact details without leaving the desktop app.",
                profileButton
        ));

        Button passwordButton = AppTheme.createButton("Change Password", AppTheme.ButtonTone.WARNING);
        passwordButton.setOnAction(event -> {
            stage.close();
            actions.openPassword();
        });
        cards.add(AppTheme.createActionCard(
                "SECURITY",
                "Credential management",
                "Rotate the current password and review the strength indicator before saving.",
                passwordButton
        ));

        Button analyticsButton = AppTheme.createButton("Open Analytics", AppTheme.ButtonTone.SECONDARY);
        analyticsButton.setOnAction(event -> {
            stage.close();
            actions.openAnalytics();
        });
        cards.add(AppTheme.createActionCard(
                "VISIBILITY",
                "Analytics studio",
                "Launch the infographic view with collection status, circulation pressure, and staff workload signals.",
                analyticsButton
        ));

        if (role.isStaff()) {
            Button usersButton = AppTheme.createButton("Manage Users", AppTheme.ButtonTone.SUCCESS);
            usersButton.setOnAction(event -> {
                stage.close();
                actions.openUserManagement();
            });
            cards.add(AppTheme.createActionCard(
                    "IDENTITY",
                    "User administration",
                    "Create, disable, and review users with the role-aware staff controls.",
                    usersButton
            ));

            Button configButton = AppTheme.createButton("Library Configuration", AppTheme.ButtonTone.PRIMARY);
            configButton.setOnAction(event -> {
                stage.close();
                actions.openLibraryConfiguration();
            });
            cards.add(AppTheme.createActionCard(
                    "OPERATIONS",
                    "Borrowing and email rules",
                    "Adjust loan windows, fines, export paths, and SMTP credentials in one place.",
                    configButton
            ));

            Button dataButton = AppTheme.createButton("Data Management", AppTheme.ButtonTone.SECONDARY);
            dataButton.setOnAction(event -> {
                stage.close();
                actions.openDataManagement();
            });
            cards.add(AppTheme.createActionCard(
                    "DATA",
                    "Backups and exports",
                    "Run backups, export reports, and move directly into analytics from the same workspace.",
                    dataButton
            ));
        }

        VBox roleBanner = new VBox(8,
                roleChip,
                new Label(role.isStaff()
                        ? "Staff accounts can manage users, inventory, borrowing rules, exports, and approvals."
                        : "User accounts can update their profile, change passwords, browse analytics, and request books.")
        );
        roleBanner.getStyleClass().addAll("surface-card");

        TilePane cardPane = new TilePane();
        cardPane.setPrefColumns(3);
        cardPane.setHgap(16);
        cardPane.setVgap(16);
        cardPane.getChildren().addAll(cards);

        VBox content = new VBox(18, roleBanner, cardPane);

        root.setTop(toolbar);
        root.setCenter(content);

        Scene scene = AppTheme.createScene(root, 1040, 700);
        stage.setScene(scene);
        AppTheme.animateChildren(List.of(toolbar, roleBanner, cardPane), 0, 90);
        stage.showAndWait();
    }
}
