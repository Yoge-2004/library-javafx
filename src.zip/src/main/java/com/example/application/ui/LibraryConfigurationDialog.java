package com.example.application.ui;

import com.example.entities.AppConfiguration;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;

public final class LibraryConfigurationDialog {

    public record ConfigurationInput(
            int maxBorrowLimit,
            int loanDays,
            double finePerDay,
            String exportDirectory,
            String smtpHost,
            int smtpPort,
            String smtpUsername,
            String smtpPassword,
            String fromAddress,
            boolean smtpAuth,
            boolean startTlsEnabled
    ) {
    }

    private LibraryConfigurationDialog() {
    }

    public static Optional<ConfigurationInput> show(
            Stage owner,
            AppConfiguration config,
            int maxBorrowLimit,
            int loanDays,
            double finePerDay
    ) {
        Stage stage = AppTheme.createModalStage(owner, "Library Configuration", 1080, 760);
        AtomicReference<ConfigurationInput> result = new AtomicReference<>();

        BorderPane root = new BorderPane();
        root.getStyleClass().addAll("app-root", "modal-root");
        root.setPadding(new Insets(24));

        HBox toolbar = new HBox(12);
        toolbar.setAlignment(Pos.CENTER_LEFT);

        VBox header = AppTheme.createHeaderBlock(
                "LIBRARY CONFIGURATION",
                "Tune circulation rules and reminder delivery",
                "Borrowing policy, exports, and SMTP delivery are grouped here so staff can update operations without editing serialized data by hand."
        );
        header.getStyleClass().add("compact-header");

        Button cancelButton = AppTheme.createButton("Cancel", AppTheme.ButtonTone.GHOST);
        Button saveButton = AppTheme.createButton("Save Changes", AppTheme.ButtonTone.SUCCESS);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        toolbar.getChildren().addAll(header, spacer, cancelButton, saveButton);

        VBox borrowingCard = new VBox(14);
        borrowingCard.getStyleClass().addAll("surface-card");
        borrowingCard.getChildren().addAll(
                sectionTitle("Borrowing Rules"),
                sectionHint("Define how many books a borrower can hold, how long a loan remains active, and how quickly overdue fines accumulate.")
        );

        TextField maxBorrowField = new TextField(String.valueOf(maxBorrowLimit));
        maxBorrowField.setPromptText("Maximum books per user");
        TextField loanDaysField = new TextField(String.valueOf(loanDays));
        loanDaysField.setPromptText("Loan period in days");
        TextField fineField = new TextField(String.format("%.2f", finePerDay));
        fineField.setPromptText("Fine per overdue day");
        TextField exportDirectoryField = new TextField(config.getExportDirectory());
        exportDirectoryField.setPromptText("Export directory");

        borrowingCard.getChildren().addAll(
                fieldGroup("Maximum books per user", maxBorrowField),
                fieldGroup("Default loan period (days)", loanDaysField),
                fieldGroup("Fine per overdue day", fineField),
                fieldGroup("Export directory", exportDirectoryField)
        );

        VBox emailCard = new VBox(14);
        emailCard.getStyleClass().addAll("surface-card");
        emailCard.getChildren().addAll(
                sectionTitle("Email Reminders"),
                sectionHint("Provide SMTP details to send overdue reminders directly from the overdue report workflow.")
        );

        TextField smtpHostField = new TextField(blankToEmpty(config.getSmtpHost()));
        smtpHostField.setPromptText("SMTP host");
        TextField smtpPortField = new TextField(String.valueOf(config.getSmtpPort()));
        smtpPortField.setPromptText("Port");
        TextField smtpUserField = new TextField(blankToEmpty(config.getSmtpUsername()));
        smtpUserField.setPromptText("SMTP username");
        PasswordField smtpPasswordField = new PasswordField();
        smtpPasswordField.setText(blankToEmpty(config.getSmtpPassword()));
        smtpPasswordField.setPromptText("SMTP password");
        TextField fromAddressField = new TextField(blankToEmpty(config.getFromAddress()));
        fromAddressField.setPromptText("From address");
        CheckBox smtpAuthBox = new CheckBox("SMTP authentication required");
        smtpAuthBox.setSelected(config.isSmtpAuth());
        CheckBox startTlsBox = new CheckBox("Enable STARTTLS");
        startTlsBox.setSelected(config.isStartTlsEnabled());

        emailCard.getChildren().addAll(
                fieldGroup("SMTP host", smtpHostField),
                fieldGroup("SMTP port", smtpPortField),
                fieldGroup("SMTP username", smtpUserField),
                fieldGroup("SMTP password", smtpPasswordField),
                fieldGroup("From address", fromAddressField),
                smtpAuthBox,
                startTlsBox
        );

        Label rulesPreview = new Label();
        rulesPreview.setWrapText(true);
        rulesPreview.getStyleClass().add("page-body");
        Label deliveryPreview = new Label();
        deliveryPreview.setWrapText(true);
        deliveryPreview.getStyleClass().add("page-body");

        VBox previewCard = new VBox(14,
                sectionTitle("Live Preview"),
                sectionHint("This summary updates as fields change so the effects are visible before saving."),
                rulesPreview,
                deliveryPreview
        );
        previewCard.getStyleClass().addAll("surface-card", "hero-panel");

        Label validationLabel = new Label();
        validationLabel.setWrapText(true);
        validationLabel.getStyleClass().add("muted-copy");

        Runnable updatePreview = () -> {
            rulesPreview.setText(String.format(
                    "Borrowers may keep up to %s books for %s days. Overdue loans accrue %s per day and exports land in %s.",
                    emptyFallback(maxBorrowField.getText(), "0"),
                    emptyFallback(loanDaysField.getText(), "0"),
                    emptyFallback(fineField.getText(), "0.00"),
                    emptyFallback(exportDirectoryField.getText(), "exports")
            ));
            boolean emailReady = !smtpHostField.getText().trim().isEmpty()
                    && !fromAddressField.getText().trim().isEmpty()
                    && (!smtpAuthBox.isSelected() || !smtpUserField.getText().trim().isEmpty());
            deliveryPreview.setText(emailReady
                    ? String.format("Reminder mail is configured for %s:%s with sender %s.",
                    emptyFallback(smtpHostField.getText(), "host"),
                    emptyFallback(smtpPortField.getText(), "587"),
                    emptyFallback(fromAddressField.getText(), "no-reply@example.com"))
                    : "Reminder mail is incomplete. Host, sender address, and optionally a username are still required.");
        };

        List<TextField> previewFields = List.of(
                maxBorrowField,
                loanDaysField,
                fineField,
                exportDirectoryField,
                smtpHostField,
                smtpPortField,
                smtpUserField,
                fromAddressField
        );
        previewFields.forEach(field -> field.textProperty().addListener((obs, oldValue, newValue) -> updatePreview.run()));
        smtpAuthBox.selectedProperty().addListener((obs, oldValue, newValue) -> updatePreview.run());
        updatePreview.run();

        VBox mainContent = new VBox(18, borrowingCard, emailCard, validationLabel);
        ScrollPane scrollPane = new ScrollPane(mainContent);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: transparent;");

        HBox center = new HBox(18, scrollPane, previewCard);
        HBox.setHgrow(scrollPane, Priority.ALWAYS);
        previewCard.setPrefWidth(320);

        cancelButton.setOnAction(event -> stage.close());
        saveButton.setOnAction(event -> {
            try {
                int parsedMaxBorrow = parsePositiveInt(maxBorrowField.getText(), "Maximum books per user");
                int parsedLoanDays = parsePositiveInt(loanDaysField.getText(), "Loan period");
                double parsedFine = parsePositiveDouble(fineField.getText(), "Fine per day");
                int parsedPort = parsePositiveInt(smtpPortField.getText(), "SMTP port");

                result.set(new ConfigurationInput(
                        parsedMaxBorrow,
                        parsedLoanDays,
                        parsedFine,
                        emptyFallback(exportDirectoryField.getText(), "exports").trim(),
                        blankToNull(smtpHostField.getText()),
                        parsedPort,
                        blankToNull(smtpUserField.getText()),
                        blankToNull(smtpPasswordField.getText()),
                        blankToNull(fromAddressField.getText()),
                        smtpAuthBox.isSelected(),
                        startTlsBox.isSelected()
                ));
                stage.close();
            } catch (IllegalArgumentException exception) {
                validationLabel.setText(exception.getMessage());
            }
        });

        root.setTop(toolbar);
        root.setCenter(center);

        Scene scene = AppTheme.createScene(root, 1080, 760);
        stage.setScene(scene);
        AppTheme.animateChildren(List.of(toolbar, center), 0, 100);
        stage.showAndWait();

        return Optional.ofNullable(result.get());
    }

    private static VBox fieldGroup(String labelText, javafx.scene.Node field) {
        Label label = new Label(labelText);
        label.getStyleClass().add("metric-title");
        VBox group = new VBox(6, label, field);
        group.setFillWidth(true);
        return group;
    }

    private static Label sectionTitle(String text) {
        Label label = new Label(text);
        label.getStyleClass().add("section-title");
        label.setStyle("-fx-font-size: 18px;");
        return label;
    }

    private static Label sectionHint(String text) {
        Label label = new Label(text);
        label.getStyleClass().add("section-subtitle");
        label.setWrapText(true);
        return label;
    }

    private static int parsePositiveInt(String value, String fieldName) {
        try {
            int parsed = Integer.parseInt(value.trim());
            if (parsed <= 0) {
                throw new IllegalArgumentException(fieldName + " must be greater than zero.");
            }
            return parsed;
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException(fieldName + " must be a valid number.");
        }
    }

    private static double parsePositiveDouble(String value, String fieldName) {
        try {
            double parsed = Double.parseDouble(value.trim());
            if (parsed < 0) {
                throw new IllegalArgumentException(fieldName + " cannot be negative.");
            }
            return parsed;
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException(fieldName + " must be a valid number.");
        }
    }

    private static String emptyFallback(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }

    private static String blankToNull(String value) {
        return value == null || value.trim().isEmpty() ? null : value.trim();
    }

    private static String blankToEmpty(String value) {
        return value == null ? "" : value;
    }
}
