package com.example.application.ui;

import javafx.animation.FadeTransition;
import javafx.animation.ParallelTransition;
import javafx.animation.PauseTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.TranslateTransition;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.net.URL;
import java.util.Collection;
import java.util.Objects;

public final class AppTheme {

    public enum ButtonTone {
        PRIMARY("btn-primary"),
        SECONDARY("btn-secondary"),
        SUCCESS("btn-success"),
        WARNING("btn-warning"),
        DANGER("btn-danger"),
        GHOST("btn-ghost");

        private final String styleClass;

        ButtonTone(String styleClass) {
            this.styleClass = styleClass;
        }

        public String getStyleClass() {
            return styleClass;
        }
    }

    private static final String ROOT_CLASS = "app-root";
    private static final String THEME_PATH = "/com/example/application/ui/theme.css";

    private AppTheme() {
    }

    public static Scene createScene(Parent root, double width, double height) {
        Scene scene = new Scene(root, width, height);
        apply(scene);
        return scene;
    }

    public static void apply(Scene scene) {
        if (scene == null) {
            return;
        }

        String stylesheet = stylesheetUrl();
        if (!scene.getStylesheets().contains(stylesheet)) {
            scene.getStylesheets().add(stylesheet);
        }

        if (scene.getRoot() != null && !scene.getRoot().getStyleClass().contains(ROOT_CLASS)) {
            scene.getRoot().getStyleClass().add(ROOT_CLASS);
        }
    }

    public static void apply(DialogPane pane) {
        if (pane == null) {
            return;
        }

        String stylesheet = stylesheetUrl();
        if (!pane.getStylesheets().contains(stylesheet)) {
            pane.getStylesheets().add(stylesheet);
        }
        if (!pane.getStyleClass().contains("dialog-pane-modern")) {
            pane.getStyleClass().add("dialog-pane-modern");
        }
    }

    public static Stage createModalStage(Stage owner, String title, double minWidth, double minHeight) {
        Stage stage = new Stage();
        if (owner != null) {
            stage.initOwner(owner);
        }
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle(title);
        stage.setMinWidth(minWidth);
        stage.setMinHeight(minHeight);
        return stage;
    }

    public static Button createButton(String text, ButtonTone tone) {
        Button button = new Button(text);
        button.getStyleClass().addAll("app-button", tone.getStyleClass());
        button.setCursor(Cursor.HAND);
        installButtonMotion(button);
        return button;
    }

    public static Label createChip(String text, String styleClass) {
        Label chip = new Label(text);
        chip.getStyleClass().addAll("info-chip", styleClass);
        return chip;
    }

    public static VBox createHeaderBlock(String eyebrow, String title, String body) {
        VBox block = new VBox(6);
        if (eyebrow != null && !eyebrow.isBlank()) {
            Label eyebrowLabel = new Label(eyebrow);
            eyebrowLabel.getStyleClass().add("page-kicker");
            block.getChildren().add(eyebrowLabel);
        }

        Label titleLabel = new Label(title);
        titleLabel.getStyleClass().add("page-title");
        titleLabel.setWrapText(true);
        block.getChildren().add(titleLabel);

        if (body != null && !body.isBlank()) {
            Label bodyLabel = new Label(body);
            bodyLabel.getStyleClass().add("page-body");
            bodyLabel.setWrapText(true);
            block.getChildren().add(bodyLabel);
        }
        return block;
    }

    public static VBox createActionCard(String eyebrow, String title, String body, Node actionNode) {
        VBox card = new VBox(14);
        card.getStyleClass().addAll("surface-card", "action-tile");
        card.setFillWidth(true);

        VBox header = createHeaderBlock(eyebrow, title, body);
        header.getStyleClass().add("compact-header");
        VBox.setVgrow(header, Priority.ALWAYS);

        card.getChildren().add(header);
        if (actionNode != null) {
            card.getChildren().add(actionNode);
        }

        installLiftMotion(card);
        return card;
    }

    public static void markSurface(Region region) {
        if (region == null) {
            return;
        }
        if (!region.getStyleClass().contains("surface-card")) {
            region.getStyleClass().add("surface-card");
        }
    }

    public static void animateEntrance(Node node, double delayMillis) {
        if (node == null) {
            return;
        }

        node.setOpacity(0);
        node.setTranslateY(24);

        PauseTransition delay = new PauseTransition(Duration.millis(delayMillis));
        delay.setOnFinished(event -> {
            FadeTransition fade = new FadeTransition(Duration.millis(360), node);
            fade.setFromValue(0);
            fade.setToValue(1);

            TranslateTransition lift = new TranslateTransition(Duration.millis(420), node);
            lift.setFromY(24);
            lift.setToY(0);

            new ParallelTransition(fade, lift).play();
        });
        delay.play();
    }

    public static void animateChildren(Collection<? extends Node> nodes, double initialDelay, double stepMillis) {
        double delay = initialDelay;
        for (Node node : nodes) {
            animateEntrance(node, delay);
            delay += stepMillis;
        }
    }

    private static void installButtonMotion(Button button) {
        Objects.requireNonNull(button, "button");
        button.hoverProperty().addListener((obs, wasHovering, isHovering) ->
                animateScale(button, isHovering ? 1.02 : 1.0, 140)
        );
        button.armedProperty().addListener((obs, wasArmed, isArmed) ->
                animateScale(button, isArmed ? 0.98 : (button.isHover() ? 1.02 : 1.0), 100)
        );
    }

    private static void installLiftMotion(Region region) {
        region.hoverProperty().addListener((obs, wasHovering, isHovering) -> {
            animateScale(region, isHovering ? 1.01 : 1.0, 160);
            TranslateTransition transition = new TranslateTransition(Duration.millis(180), region);
            transition.setToY(isHovering ? -4 : 0);
            transition.play();
        });
    }

    private static void animateScale(Node node, double scale, int millis) {
        ScaleTransition transition = new ScaleTransition(Duration.millis(millis), node);
        transition.setToX(scale);
        transition.setToY(scale);
        transition.play();
    }

    private static String stylesheetUrl() {
        URL resource = AppTheme.class.getResource(THEME_PATH);
        if (resource == null) {
            throw new IllegalStateException("Theme stylesheet not found: " + THEME_PATH);
        }
        return resource.toExternalForm();
    }
}
