package com.example.application.ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;
import java.util.Locale;

public final class DataManagementWorkspace {

    public record Snapshot(
            int totalBooks,
            int totalCopies,
            int availableCopies,
            int issuedCopies,
            int overdueBooks,
            int totalUsers,
            int pendingRequests,
            double totalFines,
            String exportDirectory,
            boolean emailConfigured
    ) {
    }

    public interface Actions {
        void createBackup();
        void exportReports();
        void openAnalytics();
    }

    private DataManagementWorkspace() {
    }

    public static void show(Stage owner, Snapshot snapshot, Actions actions) {
        Stage stage = AppTheme.createModalStage(owner, "Data Management", 1040, 720);

        BorderPane root = new BorderPane();
        root.getStyleClass().addAll("app-root", "modal-root");
        root.setPadding(new Insets(24));

        HBox toolbar = new HBox(12);
        toolbar.setAlignment(Pos.CENTER_LEFT);

        VBox header = AppTheme.createHeaderBlock(
                "DATA MANAGEMENT",
                "Backups, exports, and operational visibility",
                "This workspace centralizes the admin tasks that were previously buried in weak dialogs. Use it to protect data, export reports, and open the analytics studio."
        );
        header.getStyleClass().add("compact-header");

        Button closeButton = AppTheme.createButton("Close", AppTheme.ButtonTone.GHOST);
        closeButton.setOnAction(event -> stage.close());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        toolbar.getChildren().addAll(header, spacer, closeButton);

        TilePane metricPane = new TilePane();
        metricPane.setPrefColumns(4);
        metricPane.setHgap(12);
        metricPane.setVgap(12);
        metricPane.getChildren().addAll(
                metricCard("Collection", String.valueOf(snapshot.totalBooks()), snapshot.totalCopies() + " copies total", "metric-accent-teal"),
                metricCard("Members", String.valueOf(snapshot.totalUsers()), snapshot.pendingRequests() + " pending requests", "metric-accent-ink"),
                metricCard("Loans", String.valueOf(snapshot.issuedCopies()), snapshot.overdueBooks() + " overdue", "metric-accent-amber"),
                metricCard("Fines", String.format(Locale.US, "$%.2f", snapshot.totalFines()), "current exposure", "metric-accent-coral")
        );

        Button analyticsButton = AppTheme.createButton("Open Analytics Studio", AppTheme.ButtonTone.SECONDARY);
        analyticsButton.setOnAction(event -> actions.openAnalytics());
        VBox analyticsCard = AppTheme.createActionCard(
                "INSIGHTS",
                "Review infographics",
                "Open the expanded analytics workspace with charts and operational pressure indicators.",
                analyticsButton
        );

        Button backupButton = AppTheme.createButton("Create Backup", AppTheme.ButtonTone.SUCCESS);
        backupButton.setOnAction(event -> actions.createBackup());
        VBox backupCard = AppTheme.createActionCard(
                "SAFETY",
                "Protect serialized data",
                "Generate a timestamped backup for users, books, issue records, requests, and app configuration.",
                backupButton
        );

        Button exportButton = AppTheme.createButton("Export Reports", AppTheme.ButtonTone.PRIMARY);
        exportButton.setOnAction(event -> actions.exportReports());
        VBox exportCard = AppTheme.createActionCard(
                "REPORTING",
                "Export operational files",
                "Create CSV report packages for overdue items, active loans, and borrow requests.",
                exportButton
        );

        VBox storageCard = new VBox(12);
        storageCard.getStyleClass().addAll("surface-card");
        storageCard.getChildren().addAll(
                AppTheme.createHeaderBlock(
                        "SYSTEM SNAPSHOT",
                        "Storage and delivery status",
                        "Keep exports predictable and confirm whether reminder email is ready before staff try to notify borrowers."
                ),
                AppTheme.createChip("Exports: " + snapshot.exportDirectory(), "chip-neutral"),
                AppTheme.createChip(snapshot.emailConfigured() ? "Email reminders configured" : "Email reminders incomplete",
                        snapshot.emailConfigured() ? "chip-success" : "chip-warning"),
                new Label(String.format(
                        "Available copies: %d\nIssued copies: %d\nOverdue items: %d",
                        snapshot.availableCopies(),
                        snapshot.issuedCopies(),
                        snapshot.overdueBooks()
                ))
        );

        TilePane actionPane = new TilePane();
        actionPane.setPrefColumns(2);
        actionPane.setHgap(16);
        actionPane.setVgap(16);
        actionPane.getChildren().addAll(analyticsCard, backupCard, exportCard, storageCard);

        VBox content = new VBox(18, metricPane, actionPane);
        root.setTop(toolbar);
        root.setCenter(content);

        Scene scene = AppTheme.createScene(root, 1040, 720);
        stage.setScene(scene);
        AppTheme.animateChildren(List.of(toolbar, metricPane, actionPane), 0, 90);
        stage.showAndWait();
    }

    private static VBox metricCard(String title, String value, String helper, String accentClass) {
        Label titleLabel = new Label(title);
        titleLabel.getStyleClass().add("metric-title");

        Label valueLabel = new Label(value);
        valueLabel.getStyleClass().add("metric-value");

        Label helperLabel = new Label(helper);
        helperLabel.getStyleClass().add("metric-helper");
        helperLabel.setWrapText(true);

        VBox card = new VBox(4, titleLabel, valueLabel, helperLabel);
        card.getStyleClass().addAll("surface-card", "metric-card", accentClass);
        return card;
    }
}
