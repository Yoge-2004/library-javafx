package com.example.application.ui;

import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class AnalyticsDashboard extends VBox {

    private static final DateTimeFormatter SNAPSHOT_DATE = DateTimeFormatter.ofPattern("dd MMM yyyy");

    private final Label titleCountValue = new Label("0");
    private final Label titleCountHelper = new Label("catalog titles");
    private final Label memberCountValue = new Label("0");
    private final Label memberCountHelper = new Label("registered accounts");
    private final Label requestCountValue = new Label("0");
    private final Label requestCountHelper = new Label("pending approvals");
    private final Label fineCountValue = new Label("$0.00");
    private final Label fineCountHelper = new Label("overdue exposure");
    private final Label utilizationLabel = new Label("Circulation utilization 0%");
    private final Label overdueLabel = new Label("No overdue activity");
    private final Label snapshotLabel = new Label("Snapshot");
    private final ProgressBar utilizationBar = new ProgressBar(0);
    private final ProgressBar overdueBar = new ProgressBar(0);
    private final PieChart circulationChart;
    private final BarChart<String, Number> activityChart;

    public AnalyticsDashboard(Runnable openStudioAction) {
        setSpacing(16);
        setPadding(new Insets(18));
        getStyleClass().addAll("surface-card", "analytics-shell");

        Button studioButton = openStudioAction == null
                ? null
                : AppTheme.createButton("Open Analytics Studio", AppTheme.ButtonTone.SECONDARY);
        if (studioButton != null) {
            studioButton.setOnAction(event -> openStudioAction.run());
        }

        VBox headerBlock = AppTheme.createHeaderBlock(
                "ANALYTICS",
                "Operational snapshot",
                "Monitor circulation, request pressure, and overdue exposure without leaving the dashboard."
        );
        headerBlock.getStyleClass().add("compact-header");

        HBox header = new HBox(12);
        header.setAlignment(Pos.TOP_LEFT);
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        header.getChildren().add(headerBlock);
        if (studioButton != null) {
            header.getChildren().addAll(spacer, studioButton);
        }

        TilePane metricPane = new TilePane();
        metricPane.setHgap(12);
        metricPane.setVgap(12);
        metricPane.setPrefColumns(2);

        metricPane.getChildren().addAll(
                createMetricCard("Titles", titleCountValue, titleCountHelper, "metric-accent-teal"),
                createMetricCard("Members", memberCountValue, memberCountHelper, "metric-accent-ink"),
                createMetricCard("Requests", requestCountValue, requestCountHelper, "metric-accent-amber"),
                createMetricCard("Fine Risk", fineCountValue, fineCountHelper, "metric-accent-coral")
        );

        circulationChart = new PieChart(FXCollections.observableArrayList(
                new PieChart.Data("Available", 0),
                new PieChart.Data("Issued", 0),
                new PieChart.Data("Overdue", 0)
        ));
        circulationChart.setLegendVisible(true);
        circulationChart.setLabelsVisible(true);
        circulationChart.setPrefHeight(240);
        circulationChart.setTitle("Collection Mix");

        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        activityChart = new BarChart<>(xAxis, yAxis);
        activityChart.setLegendVisible(false);
        activityChart.setAnimated(false);
        activityChart.setCategoryGap(18);
        activityChart.setPrefHeight(280);
        activityChart.setTitle("Live Operations");

        VBox chartCard = new VBox(14, circulationChart, activityChart);
        chartCard.getStyleClass().addAll("surface-card");

        VBox insightCard = new VBox(10);
        insightCard.getStyleClass().addAll("surface-card");

        Label insightTitle = new Label("Operational pressure");
        insightTitle.getStyleClass().add("section-title");
        insightTitle.setStyle("-fx-font-size: 18px;");

        utilizationBar.setMaxWidth(Double.MAX_VALUE);
        overdueBar.setMaxWidth(Double.MAX_VALUE);
        snapshotLabel.getStyleClass().add("muted-copy");

        insightCard.getChildren().addAll(
                insightTitle,
                utilizationLabel,
                utilizationBar,
                overdueLabel,
                overdueBar,
                snapshotLabel
        );

        getChildren().addAll(header, metricPane, chartCard, insightCard);
        AppTheme.animateChildren(List.of(header, metricPane, chartCard, insightCard), 0, 90);
    }

    public void update(Map<String, Object> stats, int totalUsers, int staffUsers) {
        int titles = readInt(stats, "totalBooks");
        int totalCopies = readInt(stats, "totalCopies");
        int availableCopies = readInt(stats, "availableCopies");
        int issuedCopies = readInt(stats, "issuedCopies");
        int overdueBooks = readInt(stats, "overdueBooks");
        int pendingRequests = readInt(stats, "pendingRequests");
        double totalFines = readDouble(stats, "totalFines");
        double utilizationRate = stats.containsKey("utilizationRate")
                ? readDouble(stats, "utilizationRate") / 100.0
                : totalCopies == 0 ? 0.0 : issuedCopies / (double) totalCopies;

        titleCountValue.setText(String.valueOf(titles));
        titleCountHelper.setText(totalCopies + " copies across the collection");
        memberCountValue.setText(String.valueOf(totalUsers));
        memberCountHelper.setText(staffUsers + " staff / " + Math.max(0, totalUsers - staffUsers) + " members");
        requestCountValue.setText(String.valueOf(pendingRequests));
        requestCountHelper.setText(pendingRequests == 1 ? "1 request waiting" : pendingRequests + " requests waiting");
        fineCountValue.setText(String.format(Locale.US, "$%.2f", totalFines));
        fineCountHelper.setText(overdueBooks == 0 ? "no overdue balance" : overdueBooks + " overdue loans");

        circulationChart.setData(FXCollections.observableArrayList(
                new PieChart.Data("Available", availableCopies),
                new PieChart.Data("Issued", issuedCopies),
                new PieChart.Data("Overdue", overdueBooks)
        ));

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.getData().add(new XYChart.Data<>("Titles", titles));
        series.getData().add(new XYChart.Data<>("Members", totalUsers));
        series.getData().add(new XYChart.Data<>("Requests", pendingRequests));
        series.getData().add(new XYChart.Data<>("Overdue", overdueBooks));
        activityChart.getData().setAll(series);

        utilizationBar.setProgress(clamp(utilizationRate));
        utilizationLabel.setText(String.format(Locale.US,
                "Circulation utilization %.0f%% of %d total copies",
                utilizationRate * 100,
                totalCopies
        ));

        double overdueRatio = issuedCopies == 0 ? 0.0 : overdueBooks / (double) issuedCopies;
        overdueBar.setProgress(clamp(overdueRatio));
        overdueLabel.setText(overdueBooks == 0
                ? "No overdue items currently need intervention"
                : String.format(Locale.US, "Overdue pressure %.0f%% of active loans", overdueRatio * 100));

        Object generatedAt = stats.getOrDefault("generatedAt", LocalDate.now());
        snapshotLabel.setText("Snapshot generated " + generatedAt);
    }

    public static void showStudio(Stage owner, Map<String, Object> stats, int totalUsers, int staffUsers) {
        Stage stage = AppTheme.createModalStage(owner, "Analytics Studio", 1160, 820);

        BorderPane root = new BorderPane();
        root.getStyleClass().addAll("app-root", "modal-root");

        HBox toolbar = new HBox(12);
        toolbar.setAlignment(Pos.CENTER_LEFT);
        toolbar.setPadding(new Insets(24, 28, 12, 28));

        VBox headerBlock = AppTheme.createHeaderBlock(
                "ANALYTICS STUDIO",
                "Library performance in one view",
                "This workspace groups the operational infographics so staff can review collection health and workload without digging through dialogs."
        );
        headerBlock.getStyleClass().add("compact-header");

        Button closeButton = AppTheme.createButton("Close", AppTheme.ButtonTone.GHOST);
        closeButton.setOnAction(event -> stage.close());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        toolbar.getChildren().addAll(headerBlock, spacer, closeButton);

        AnalyticsDashboard dashboard = new AnalyticsDashboard(null);
        dashboard.update(stats, totalUsers, staffUsers);

        ScrollPane scrollPane = new ScrollPane(dashboard);
        scrollPane.setFitToWidth(true);
        scrollPane.setPadding(new Insets(0, 24, 24, 24));
        scrollPane.setStyle("-fx-background-color: transparent;");

        root.setTop(toolbar);
        root.setCenter(scrollPane);

        Scene scene = AppTheme.createScene(root, 1160, 820);
        stage.setScene(scene);
        stage.showAndWait();
    }

    private VBox createMetricCard(String title, Label valueLabel, Label helperLabel, String accentClass) {
        valueLabel.getStyleClass().add("metric-value");
        helperLabel.getStyleClass().add("metric-helper");

        Label titleLabel = new Label(title);
        titleLabel.getStyleClass().add("metric-title");

        VBox card = new VBox(4, titleLabel, valueLabel, helperLabel);
        card.getStyleClass().addAll("surface-card", "metric-card", accentClass);
        return card;
    }

    private int readInt(Map<String, Object> stats, String key) {
        return ((Number) stats.getOrDefault(key, 0)).intValue();
    }

    private double readDouble(Map<String, Object> stats, String key) {
        return ((Number) stats.getOrDefault(key, 0.0)).doubleValue();
    }

    private double clamp(double value) {
        return Math.max(0.0, Math.min(1.0, value));
    }
}
