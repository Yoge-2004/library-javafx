package com.example.application;

import com.example.entities.BooksDB.IssueRecord;

import java.util.List;
import java.util.Objects;

final class OverdueReportFormatter {

    private OverdueReportFormatter() {
    }

    static String format(List<IssueRecord> overdueBooks) {
        Objects.requireNonNull(overdueBooks, "overdueBooks cannot be null");

        StringBuilder report = new StringBuilder("Overdue Books Report:\n\n");
        double totalFines = 0;

        for (IssueRecord record : overdueBooks) {
            double fine = record.calculateFine();
            totalFines += fine;
            report.append(String.format(
                    "Book: %s\nUser: %s\nDue Date: %s\nDays Overdue: %d\nFine: $%.2f\n\n",
                    record.getBookTitle(),
                    record.getUserId(),
                    record.getDueDate(),
                    record.getDaysOverdue(),
                    fine
            ));
        }

        report.append(String.format("Total Outstanding Fines: $%.2f", totalFines));
        return report.toString();
    }
}
