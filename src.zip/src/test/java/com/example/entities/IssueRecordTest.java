package com.example.entities;

import com.example.entities.BooksDB.IssueRecord;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class IssueRecordTest {

    @Test
    void overdueActiveRecordCalculatesDaysAndFine() {
        IssueRecord record = new IssueRecord("ISBN-001", "Domain-Driven Design", "alice",
                LocalDate.now().minusDays(21), 1);

        assertTrue(record.isOverdue());
        assertEquals(7, record.getDaysOverdue());
        assertEquals(14.0, record.calculateFine());
    }

    @Test
    void returnedRecordIsNotMarkedOverdueButKeepsHistoricalFineCalculation() {
        IssueRecord record = new IssueRecord("ISBN-002", "Working Effectively with Legacy Code", "bob",
                LocalDate.now().minusDays(20), 1);
        record.setReturned(true);
        record.setReturnDate(LocalDate.now());

        assertFalse(record.isOverdue());
        assertEquals(6, record.getDaysOverdue());
        assertEquals(12.0, record.calculateFine());
    }

    @Test
    void missingFineRateFallsBackToDefaultFinePerDay() {
        IssueRecord record = new IssueRecord("ISBN-003", "Patterns of Enterprise Application Architecture", "charlie",
                LocalDate.now().minusDays(18), 1);
        record.setFinePerDayRate(0.0);

        assertEquals(4, record.getDaysOverdue());
        assertEquals(8.0, record.calculateFine());
    }
}
