package com.example.application;

import com.example.entities.BooksDB.IssueRecord;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertTrue;

class OverdueReportFormatterTest {

    @Test
    void formatIncludesEachRecordAndTotalFine() {
        IssueRecord first = new IssueRecord("ISBN-001", "Clean Code", "alice", LocalDate.now().minusDays(20), 1);
        IssueRecord second = new IssueRecord("ISBN-002", "Refactoring", "bob", LocalDate.now().minusDays(17), 1);

        String report = OverdueReportFormatter.format(List.of(first, second));

        assertAll(
                () -> assertTrue(report.contains("Overdue Books Report:")),
                () -> assertTrue(report.contains("Book: Clean Code")),
                () -> assertTrue(report.contains("User: alice")),
                () -> assertTrue(report.contains("Days Overdue: 6")),
                () -> assertTrue(report.contains("Fine: $12.00")),
                () -> assertTrue(report.contains("Book: Refactoring")),
                () -> assertTrue(report.contains("User: bob")),
                () -> assertTrue(report.contains("Days Overdue: 3")),
                () -> assertTrue(report.contains("Fine: $6.00")),
                () -> assertTrue(report.contains("Total Outstanding Fines: $18.00"))
        );
    }
}
